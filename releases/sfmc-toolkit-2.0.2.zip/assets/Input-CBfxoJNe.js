import{c as a,o as r,a as n,J as u,u as i,bL as d}from"./app-DewNrkTU.js";/**
 * @license lucide-vue-next v1.0.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=a("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]),p=["value"],f={__name:"Input",props:{class:{type:String,default:""},modelValue:{type:String,default:""}},emits:["update:modelValue"],setup(e){const l=e;return(t,s)=>(r(),n("input",u({value:e.modelValue,class:i(d)("flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",l.class)},t.$attrs,{onInput:s[0]||(s[0]=o=>t.$emit("update:modelValue",o.target.value))}),null,16,p))}};export{m as P,f as _};
