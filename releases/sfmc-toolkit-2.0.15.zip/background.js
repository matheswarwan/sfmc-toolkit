//#region src/background/apps.js
var STACK_RE = /^s?\d+$/;
var mdY = (t) => {
	const d = new Date(t);
	return `${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}-${d.getFullYear()}`;
};
var SFMC_APPS = [
	{
		id: "automationStudio",
		name: "Automation Studio",
		matches: (url) => url.hostname.startsWith("mc.") && url.pathname.startsWith("/AutomationStudioFuel3/"),
		bearer: true,
		probeUrl: (s) => `https://mc.${s}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi/automation/v1/automations?$page=1&$pageSize=1`,
		landings: (s) => [`https://mc.${s}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`, `https://mc.${s}.exacttarget.com/cloud/#app/Automation%20Studio/AutomationStudioFuel3/`]
	},
	{
		id: "contactsMeta",
		name: "Data Extensions",
		matches: (url) => url.hostname.startsWith("mc.") && url.pathname.startsWith("/contactsmeta/"),
		bearer: true,
		probeUrl: (s) => `https://mc.${s}.marketingcloudapps.com/contactsmeta/fuelapi/legacy/v1/beta/folder`,
		landings: (s) => [`https://mc.${s}.marketingcloudapps.com/contactsmeta/`, `https://mc.${s}.exacttarget.com/cloud/#app/Contact%20Builder`]
	},
	{
		id: "dataUi",
		onDemand: true,
		name: "Data Extension storage",
		matches: (url) => url.hostname.startsWith("mc-data-ui."),
		bearer: true,
		probeUrl: (s) => `https://mc-data-ui.${s}.marketingcloudapps.com/fuelapi/data/v1/customobjects/storageHistory?startDate=${mdY(Date.now() - 864e5)}&endDate=${mdY(Date.now())}`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Contact%20Builder`]
	},
	{
		id: "contentBuilder",
		name: "Content Builder",
		matches: (url) => url.hostname.startsWith("content-builder."),
		bearer: true,
		csrfCookie: "_csrf",
		probeUrl: (s) => `https://content-builder.${s}.marketingcloudapps.com/fuelapi/asset/v1/content/categories/?categoryType=cloudpages&$page=1&$pagesize=1`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Content%20Builder`]
	},
	{
		id: "cloudPages",
		name: "CloudPages",
		matches: (url) => url.hostname.startsWith("cloud-pages."),
		bearer: false,
		probeUrl: (s) => `https://cloud-pages.${s}.marketingcloudapps.com/fuelapi/internal/v2/cloudpages/sites?$page=1&$pagesize=1`,
		landings: (s) => [`https://cloud-pages.${s}.marketingcloudapps.com/update-token.json`, `https://mc.${s}.exacttarget.com/cloud/#app/CloudPages`]
	},
	{
		id: "journeyBuilder",
		name: "Journey Builder",
		matches: (url) => url.hostname.startsWith("jbinteractions."),
		bearer: false,
		probeUrl: (s) => `https://jbinteractions.${s}.marketingcloudapps.com/fuelapi/interaction/v1/eventDefinitions?$page=1&$pagesize=1`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Journey%20Builder`]
	}
];
function findApp(appId) {
	return SFMC_APPS.find((a) => a.id === appId) || null;
}
function resolveUrl(rawUrl) {
	let url;
	try {
		url = new URL(rawUrl);
	} catch {
		return {
			stack: null,
			family: null,
			app: null
		};
	}
	const labels = url.hostname.split(".");
	const stack = labels.length >= 4 && STACK_RE.test(labels[1]) ? labels[1] : null;
	if (/^(?:mc|members)\.[^.]+\.exacttarget\.com$/.test(url.hostname)) return {
		stack,
		family: "core",
		app: null
	};
	if (url.hostname.endsWith(".marketingcloudapps.com")) return {
		stack,
		family: "mca",
		app: SFMC_APPS.find((a) => a.matches(url)) || null
	};
	return {
		stack: null,
		family: null,
		app: null
	};
}
function stackFromPageUrl(rawUrl) {
	if (!rawUrl || rawUrl.includes("/login") || rawUrl.includes("mc.login.")) return null;
	const m = rawUrl.match(/^https:\/\/[a-z-]+\.([^.]+)\.(?:exacttarget|marketingcloudapps)\.com\//);
	return m && STACK_RE.test(m[1]) ? m[1] : null;
}
//#endregion
//#region src/background/chromeAsync.js
function storageGet(area, keys) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].get(keys, (r) => resolve(r || {}));
		} catch {
			resolve({});
		}
	});
}
function storageSet(area, items) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].set(items, () => resolve());
		} catch {
			resolve();
		}
	});
}
function storageRemove(area, keys) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].remove(keys, () => resolve());
		} catch {
			resolve();
		}
	});
}
function queryTabs(queryInfo = {}) {
	return new Promise((resolve) => {
		try {
			chrome.tabs.query(queryInfo, (tabs) => resolve(tabs || []));
		} catch {
			resolve([]);
		}
	});
}
function getCookie(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.get(details, (c) => resolve(c || null));
		} catch {
			resolve(null);
		}
	});
}
function getAllCookies(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.getAll(details, (c) => resolve(c || []));
		} catch {
			resolve([]);
		}
	});
}
function createTab(props) {
	return new Promise((resolve) => {
		try {
			chrome.tabs.create(props, (tab) => resolve(chrome.runtime.lastError ? null : tab || null));
		} catch {
			resolve(null);
		}
	});
}
function removeTab(tabId) {
	try {
		chrome.tabs.remove(tabId, () => void chrome.runtime.lastError);
	} catch {}
}
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
//#endregion
//#region src/background/stack.js
var STACK_IDS = [
	"s1",
	"s4",
	"s6",
	"s7",
	"s8",
	"s10",
	"s11",
	"s12",
	"s13",
	"s50",
	"s51",
	"401",
	"402",
	"403"
];
var CORE_AUTH_COOKIE_NAMES = /* @__PURE__ */ new Set([
	"ETAuthCookie",
	"ASP.NET_SessionId",
	"platformAuthCookie"
]);
var STACK_FROM_CORE_HOST = /^(?:mc|members)\.([^.]+)\.exacttarget\.com$/;
var sfmcSession = {};
var forgetHooks = [];
function onForgetStack(fn) {
	forgetHooks.push(fn);
}
var STACKLESS_PAGE = /^https:\/\/(?:mc|members)\.exacttarget\.com\//;
var STACK_IN_REQUEST = /^https:\/\/[a-z0-9-]+\.([^.]+)\.(?:exacttarget|marketingcloudapps)\.com\//;
var tabStacks = {};
var tabStacksLoaded = null;
function loadTabStacks() {
	if (!tabStacksLoaded) tabStacksLoaded = storageGet("session", "tabStacks").then((r) => {
		Object.assign(tabStacks, {
			...r.tabStacks || {},
			...tabStacks
		});
	}).catch(() => {});
	return tabStacksLoaded;
}
function noteRequestStack(details) {
	if (!details || details.tabId == null || details.tabId < 0) return;
	const m = String(details.url || "").match(STACK_IN_REQUEST);
	if (!m || !STACK_RE.test(m[1]) || tabStacks[details.tabId] === m[1]) return;
	tabStacks[details.tabId] = m[1];
	storageSet("session", { tabStacks: { ...tabStacks } });
}
function isStacklessPage(url) {
	return STACKLESS_PAGE.test(url || "") && !url.includes("/login") && !url.includes("mc.login.");
}
function tabStack(tab) {
	const fromUrl = stackFromPageUrl(tab?.url);
	if (fromUrl || !isStacklessPage(tab?.url)) return fromUrl;
	if (tabStacks[tab.id]) return tabStacks[tab.id];
	const ctx = sfmcSession[new URL(tab.url).hostname];
	return ctx?.stackKey && STACK_RE.test(ctx.stackKey) ? ctx.stackKey : null;
}
async function rememberActiveStack(url, tabId) {
	await loadTabStacks();
	const stack = tabStack({
		url,
		id: tabId
	});
	if (stack) storageSet("session", { lastActiveStack: {
		stack,
		ts: Date.now()
	} });
}
async function scanCookieStacks() {
	const now = Date.now() / 1e3;
	const stacks = [];
	for (const c of await getAllCookies({ domain: "exacttarget.com" })) {
		if (!CORE_AUTH_COOKIE_NAMES.has(c.name)) continue;
		if (c.expirationDate && c.expirationDate <= now) continue;
		const m = c.domain.replace(/^\./, "").match(STACK_FROM_CORE_HOST);
		if (m && STACK_RE.test(m[1]) && !stacks.includes(m[1])) stacks.push(m[1]);
	}
	return stacks;
}
async function openStackTabs() {
	await loadTabStacks();
	const list = [];
	const stackless = [];
	for (const t of await queryTabs({})) {
		const stack = tabStack(t);
		if (stack) list.push({
			stack,
			lastAccessed: t.lastAccessed || 0
		});
		else if (isStacklessPage(t.url)) stackless.push(t);
	}
	if (stackless.length) {
		const live = await firstLiveStack();
		if (live) for (const t of stackless) {
			noteRequestStack({
				tabId: t.id,
				url: `https://mc.${live}.exacttarget.com/`
			});
			list.push({
				stack: live,
				lastAccessed: t.lastAccessed || 0
			});
		}
	}
	return list.sort((a, b) => b.lastAccessed - a.lastAccessed);
}
function firstLiveStack() {
	return Promise.any(STACK_IDS.map((id) => verifyStack(id).then((ok) => {
		if (ok) return id;
		throw new Error("no");
	}))).catch(() => null);
}
async function verifyStack(stack) {
	try {
		return (await fetch(`https://mc.${stack}.exacttarget.com/cloud/fuelapi/data-internal/v1/customobjects/category/0?retrievalType=1&$page=1&$pagesize=1`, {
			credentials: "include",
			redirect: "manual"
		})).status === 200;
	} catch {
		return false;
	}
}
function probeStacks() {
	return Promise.any(STACK_IDS.map((id) => fetch(`https://mc.${id}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`, {
		credentials: "include",
		redirect: "manual"
	}).then((r) => {
		if (r.status === 200) return id;
		throw new Error("not this stack");
	}))).catch(() => null);
}
async function collectStackCandidates() {
	const found = /* @__PURE__ */ new Map();
	const add = (stack, source) => {
		if (!stack || !STACK_RE.test(stack)) return;
		if (!found.has(stack)) found.set(stack, /* @__PURE__ */ new Set());
		found.get(stack).add(source);
	};
	for (const t of await openStackTabs()) add(t.stack, "tab");
	for (const s of await scanCookieStacks()) add(s, "cookie");
	for (const ctx of Object.values(sfmcSession)) add(ctx?.stackKey, "session");
	return [...found].map(([stack, sources]) => ({
		stack,
		sources: [...sources]
	}));
}
async function resolveStack() {
	const { stackOverride } = await storageGet("local", "stackOverride");
	if (stackOverride && STACK_RE.test(stackOverride)) return {
		stack: stackOverride,
		source: "manual"
	};
	const tabs = await openStackTabs();
	const { lastActiveStack } = await storageGet("session", "lastActiveStack");
	if (lastActiveStack?.stack && tabs.some((t) => t.stack === lastActiveStack.stack)) return {
		stack: lastActiveStack.stack,
		source: "tab"
	};
	if (tabs.length) return {
		stack: tabs[0].stack,
		source: "tab"
	};
	const cookieStacks = await scanCookieStacks();
	if (cookieStacks.length === 1) return {
		stack: cookieStacks[0],
		source: "cookie"
	};
	if (cookieStacks.length > 1) {
		const checks = await Promise.all(cookieStacks.map(verifyStack));
		const live = cookieStacks.find((_, i) => checks[i]);
		return live ? {
			stack: live,
			source: "cookie"
		} : {
			stack: null,
			source: null
		};
	}
	const probed = await probeStacks();
	return {
		stack: probed,
		source: probed ? "probe" : null
	};
}
async function publishStack(stack) {
	if (!stack) return;
	const { sfmcStack } = await storageGet("local", "sfmcStack");
	if (sfmcStack !== stack) await storageSet("local", {
		sfmcStack: stack,
		sfmcStackTs: Date.now()
	});
}
async function resolveAndPublish() {
	const resolved = await resolveStack();
	if (resolved.stack) await publishStack(resolved.stack);
	return resolved;
}
async function forgetStack(stack) {
	if (!stack) return;
	console.warn("[Toolkit:SW] Forgetting stack after an auth failure:", stack);
	for (const fn of forgetHooks) fn(stack);
	for (const [k, ctx] of Object.entries(sfmcSession)) if (ctx?.stackKey === stack) delete sfmcSession[k];
	const { sfmcStack } = await storageGet("local", "sfmcStack");
	if (sfmcStack === stack) await storageRemove("local", ["sfmcStack", "sfmcStackTs"]);
	const { lastActiveStack } = await storageGet("session", "lastActiveStack");
	if (lastActiveStack?.stack === stack) await storageRemove("session", "lastActiveStack");
}
async function getStacks() {
	const [candidates, resolved, { stackOverride }] = await Promise.all([
		collectStackCandidates(),
		resolveStack(),
		storageGet("local", "stackOverride")
	]);
	return {
		candidates,
		resolved: resolved.stack,
		source: resolved.source,
		override: stackOverride || null
	};
}
async function setStackOverride(value) {
	const stack = value ? String(value).trim().toLowerCase() : null;
	if (stack && !STACK_RE.test(stack)) return { error: "A stack looks like s10 or 401." };
	if (stack) await storageSet("local", { stackOverride: stack });
	else await storageRemove("local", "stackOverride");
	const r = await resolveAndPublish();
	return {
		stack: r.stack,
		source: r.source
	};
}
function captureContext(ctx) {
	if (!ctx?.hostname) return;
	sfmcSession[ctx.hostname] = ctx;
	if (ctx.stackKey) sfmcSession["_stack_" + ctx.stackKey] = ctx;
}
async function getSession(stackKey) {
	if (stackKey && sfmcSession["_stack_" + stackKey]) return { session: sfmcSession["_stack_" + stackKey] };
	const { stack } = await resolveAndPublish();
	if (!stack) return { session: null };
	return { session: sfmcSession["_stack_" + stack] || { stackKey: stack } };
}
//#endregion
//#region src/background/csrf.js
var MAX_AGE$1 = 84e4;
var csrfCache = {};
async function restoreCsrfTokens() {
	const { _csrfTokens: stored = {} } = await storageGet("local", "_csrfTokens");
	const now = Date.now();
	for (const [stack, entry] of Object.entries(stored)) if (entry?.csrfToken && now - (entry.csrfCapturedAt || 0) < MAX_AGE$1) csrfCache[stack] = {
		token: entry.csrfToken,
		capturedAt: entry.csrfCapturedAt
	};
}
async function rememberCsrf(stack, token) {
	if (!stack || !token || token === csrfCache[stack]?.token) return;
	const capturedAt = Date.now();
	csrfCache[stack] = {
		token,
		capturedAt
	};
	const { _csrfTokens: stored = {} } = await storageGet("local", "_csrfTokens");
	stored[stack] = {
		csrfToken: token,
		csrfCapturedAt: capturedAt
	};
	await storageSet("local", { _csrfTokens: stored });
}
function getCoreCsrf(stack) {
	const entry = stack && csrfCache[stack];
	return entry && Date.now() - entry.capturedAt < MAX_AGE$1 ? entry.token : null;
}
function sniffCsrf(details) {
	if (!details.requestHeaders) return;
	const m = details.url.match(/(?:mc|members)\.([^.]+)\.exacttarget\.com/);
	if (!m) return;
	const h = details.requestHeaders.find((x) => x.name.toLowerCase() === "x-csrf-token");
	if (h?.value) rememberCsrf(m[1], h.value);
}
async function getAppCsrf(rawUrl, cookieName = "_csrf") {
	try {
		const cookie = await getCookie({
			url: new URL(rawUrl).origin + "/",
			name: cookieName
		});
		if (!cookie?.value) return null;
		try {
			return decodeURIComponent(cookie.value);
		} catch {
			return cookie.value;
		}
	} catch {
		return null;
	}
}
//#endregion
//#region src/background/pageHeaders.js
var MAX_AGE = 18e5;
var KEY = "_cbPageHeaders";
var cache$2 = {};
/** contactsmeta paths that need the page's headers. */
function needsPageHeaders(url) {
	return /\/contactsmeta\/fuelapi\/(contacts(-internal)?\/|legacy\/v1\/beta\/contact\/)/i.test(String(url || ""));
}
var stackOf = (url) => String(url || "").match(/^https:\/\/mc\.([^.]+)\.marketingcloudapps\.com\/contactsmeta\//i)?.[1]?.toLowerCase() || null;
async function restorePageHeaders() {
	try {
		const { [KEY]: stored = {} } = await storageGet("session", KEY);
		const now = Date.now();
		for (const [stack, e] of Object.entries(stored)) if (e && now - (e.capturedAt || 0) < MAX_AGE) cache$2[stack] = e;
	} catch {}
}
async function persist() {
	try {
		await storageSet("session", { [KEY]: cache$2 });
	} catch {}
}
/**
* webRequest.onBeforeSendHeaders listener for contactsmeta. Only SFMC's own page
* requests count (the extension's requests have no tab, or the extension's origin).
*/
function sniffPageHeaders(details) {
	if (!details?.requestHeaders || details.tabId < 0) return;
	if (String(details.initiator || "").startsWith("chrome-extension://")) return;
	const stack = stackOf(details.url);
	if (!stack) return;
	const get = (n) => details.requestHeaders.find((h) => h.name.toLowerCase() === n)?.value || null;
	const authorization = get("authorization");
	const csrf = get("x-csrf-token");
	const tz = get("tz");
	if (!authorization && !csrf) return;
	const prev = cache$2[stack] || {};
	const now = Date.now();
	cache$2[stack] = {
		authorization: authorization || prev.authorization || null,
		csrf: csrf || prev.csrf || null,
		tz: tz || prev.tz || null,
		capturedAt: now,
		csrfAt: csrf ? now : prev.csrfAt || 0
	};
	persist();
}
/** The headers to send for a contacts call, or null when none are known. */
function pageHeadersFor(stack) {
	const e = stack && cache$2[stack];
	if (!e || Date.now() - e.capturedAt > MAX_AGE) return null;
	const h = { "X-Requested-With": "XMLHttpRequest" };
	if (e.authorization) h.Authorization = e.authorization;
	if (e.csrf && Date.now() - e.csrfAt < MAX_AGE) h["X-CSRF-Token"] = e.csrf;
	if (e.tz) h.tz = e.tz;
	return h;
}
function dropPageHeaders(stack) {
	delete cache$2[stack];
	persist();
}
var pageTiming = {
	waitMs: 2e4,
	pollMs: 500
};
var inFlight$2 = /* @__PURE__ */ new Map();
/**
* Opens Contact Builder's All Contacts screen in an inactive tab until its requests
* have shown the headers (a CSRF token when `needCsrf`), then closes it. Resolves to
* the headers or null. One at a time per stack.
*/
function capturePageHeaders(stack, { needCsrf = true } = {}) {
	if (inFlight$2.has(stack)) return inFlight$2.get(stack);
	const ok = () => {
		const h = pageHeadersFor(stack);
		return h && h.Authorization && (!needCsrf || h["X-CSRF-Token"]) ? h : null;
	};
	const p = (async () => {
		if (ok()) return ok();
		const tab = await createTab({
			url: `https://mc.${stack}.marketingcloudapps.com/contactsmeta/admin.html#admin/all-contacts`,
			active: false
		});
		if (!tab) return null;
		try {
			const deadline = Date.now() + pageTiming.waitMs;
			while (Date.now() < deadline) {
				await new Promise((r) => setTimeout(r, pageTiming.pollMs));
				if (ok()) return ok();
			}
			return pageHeadersFor(stack);
		} finally {
			removeTab(tab.id);
		}
	})().finally(() => inFlight$2.delete(stack));
	inFlight$2.set(stack, p);
	return p;
}
//#endregion
//#region src/background/mcaToken.js
var mintTiming = {
	timeoutMs: 1e4,
	backoffMs: 12e4
};
var tokenCache = {};
var inFlight$1 = {};
var failedAt$1 = {};
var pendingByTab = /* @__PURE__ */ new Map();
var onMintFailure = () => {};
function setOnMintFailure(fn) {
	onMintFailure = fn;
}
function mintBackoff(stack) {
	return Date.now() - (failedAt$1[stack] || 0) < mintTiming.backoffMs;
}
function isMcaTokenReady(stack) {
	const cached = stack && tokenCache[stack];
	return !!cached && Date.now() < cached.expiresAt;
}
function dropMcaToken(stack) {
	delete tokenCache[stack];
}
function decodeJwtExp(jwt) {
	try {
		const payload = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
		const json = JSON.parse(atob(payload + "===".slice((payload.length + 3) % 4)));
		return json.exp ? json.exp * 1e3 : null;
	} catch {
		return null;
	}
}
function handleCapturedToken(sender, accessToken) {
	const resolve = pendingByTab.get(sender?.tab?.id);
	if (resolve) resolve(accessToken || null);
}
function mint(stack) {
	if (inFlight$1[stack]) return inFlight$1[stack];
	const promise = new Promise((resolve) => {
		let settled = false;
		let tabId = null;
		const finish = (token) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			if (tabId != null) {
				pendingByTab.delete(tabId);
				removeTab(tabId);
			}
			resolve(token);
		};
		const timer = setTimeout(() => {
			console.warn("[Toolkit:SW] MCA token mint timed out for stack:", stack);
			finish(null);
		}, mintTiming.timeoutMs);
		createTab({
			url: `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`,
			active: false
		}).then((tab) => {
			if (!tab) return finish(null);
			tabId = tab.id;
			if (settled) return removeTab(tabId);
			pendingByTab.set(tabId, finish);
		});
	}).finally(() => {
		delete inFlight$1[stack];
	});
	inFlight$1[stack] = promise;
	return promise;
}
async function getMcaToken(stack) {
	if (!stack) return null;
	if (isMcaTokenReady(stack)) return tokenCache[stack].accessToken;
	if (mintBackoff(stack)) return null;
	const accessToken = await mint(stack);
	if (!accessToken) {
		failedAt$1[stack] = Date.now();
		onMintFailure(stack);
		return null;
	}
	delete failedAt$1[stack];
	tokenCache[stack] = {
		accessToken,
		expiresAt: (decodeJwtExp(accessToken) || Date.now() + 6e5) - 3e4
	};
	return accessToken;
}
//#endregion
//#region src/background/sessions.js
var LOGIN_REQUIRED = "SFMC_LOGIN_REQUIRED";
var SESSION_UNAVAILABLE = "SFMC_SESSION_UNAVAILABLE";
var timing = {
	pollMs: 1e3,
	landingTimeoutMs: 15e3,
	cooldownMs: 3e4
};
var LOGIN_COOKIES = [{
	host: (s) => `mc.${s}.exacttarget.com`,
	name: "platformAuthCookie"
}, {
	host: (s) => `members.${s}.exacttarget.com`,
	name: "ETAuthCookie"
}];
var inFlight = /* @__PURE__ */ new Map();
var failedAt = /* @__PURE__ */ new Map();
var starting = /* @__PURE__ */ new Set();
var warmedAt = /* @__PURE__ */ new Map();
var SfmcAuthError = class extends Error {
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
async function isLoggedIn(stack) {
	for (const c of LOGIN_COOKIES) if (await getCookie({
		url: `https://${c.host(stack)}/`,
		name: c.name
	})) return true;
	return false;
}
async function probeSession(app, stack) {
	try {
		return (await fetch(app.probeUrl(stack), {
			credentials: "include",
			redirect: "manual"
		})).status === 200;
	} catch {
		return false;
	}
}
async function tryLanding(app, stack, landingUrl) {
	const tab = await createTab({
		url: landingUrl,
		active: false
	});
	if (!tab) return false;
	try {
		const deadline = Date.now() + timing.landingTimeoutMs;
		while (Date.now() < deadline) {
			await delay(timing.pollMs);
			if (await probeSession(app, stack)) return true;
		}
		return false;
	} finally {
		removeTab(tab.id);
	}
}
function ensureSession(app, stack, { onLoggedOut } = {}) {
	const key = `${stack}:${app.id}`;
	if (inFlight.has(key)) return inFlight.get(key);
	const last = failedAt.get(key);
	if (last && Date.now() - last < timing.cooldownMs) return Promise.reject(new SfmcAuthError(SESSION_UNAVAILABLE, `Could not start a ${app.name} session on stack ${stack}.`));
	const promise = (async () => {
		if (await probeSession(app, stack)) return;
		if (!await isLoggedIn(stack)) {
			await onLoggedOut?.(stack);
			throw new SfmcAuthError(LOGIN_REQUIRED, `Not logged in to Marketing Cloud on stack ${stack}.`);
		}
		for (const url of app.landings(stack)) if (await tryLanding(app, stack, url)) return;
		throw new SfmcAuthError(SESSION_UNAVAILABLE, `Could not start a ${app.name} session on stack ${stack}.`);
	})().then(() => {
		failedAt.delete(key);
	}).catch((err) => {
		failedAt.set(key, Date.now());
		throw err;
	}).finally(() => {
		inFlight.delete(key);
	});
	inFlight.set(key, promise);
	return promise;
}
async function sessionStatus(stack) {
	const loggedIn = await isLoggedIn(stack);
	return {
		stack,
		loggedIn,
		apps: await Promise.all(SFMC_APPS.filter((app) => !app.onDemand).map(async (app) => ({
			id: app.id,
			name: app.name,
			ok: loggedIn && await probeSession(app, stack),
			starting: starting.has(`${stack}:${app.id}`)
		})))
	};
}
async function connectApp(stack, appId, opts) {
	const app = findApp(appId);
	if (!app) throw new Error(`Unknown SFMC app: ${appId}`);
	failedAt.delete(`${stack}:${app.id}`);
	await ensureSession(app, stack, opts);
}
/**
* Starts the app sessions that are missing, but only when at least one app already
* has a session: then the user is logged in and SFMC answers, so the rest can be
* started. With none, the user is most likely not logged in and opening tabs would
* not help. Apps are started one at a time (one inactive tab each), at most once
* every 10 minutes per stack unless `force`.
* @returns {{ skipped?: string, started?: string[], failed?: string[] }}
*/
async function warmUpMissing(stack, { force = false, onLoggedOut } = {}) {
	if (!stack) return { skipped: "no stack" };
	const last = warmedAt.get(stack);
	if (!force && last && Date.now() - last < 6e5) return { skipped: "recently" };
	const status = await sessionStatus(stack);
	if (!status.loggedIn) return { skipped: "not logged in" };
	if (!status.apps.some((a) => a.ok)) return { skipped: "no app session" };
	warmedAt.set(stack, Date.now());
	const missing = status.apps.filter((a) => !a.ok).map((a) => findApp(a.id));
	const started = [];
	const failed = [];
	for (const app of missing) starting.add(`${stack}:${app.id}`);
	try {
		for (const app of missing) try {
			failedAt.delete(`${stack}:${app.id}`);
			await ensureSession(app, stack, { onLoggedOut });
			started.push(app.id);
		} catch (e) {
			failed.push(app.id);
			if (e.code === "SFMC_LOGIN_REQUIRED") break;
		} finally {
			starting.delete(`${stack}:${app.id}`);
		}
	} finally {
		for (const app of missing) starting.delete(`${stack}:${app.id}`);
	}
	return {
		started,
		failed
	};
}
//#endregion
//#region src/background/fetchProxy.js
/**
* SFMC's own HTML error pages (IIS "403 Not Authorized") turned into their title,
* so a message reads "Not Authorized" instead of a page of markup (feedback #67).
*/
function errorText(text) {
	const t = String(text ?? "");
	if (!/^\s*(<!DOCTYPE html|<html)/i.test(t)) return t;
	const pick = (tag) => (t.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"))?.[1] || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
	return pick("title") || pick("h1") || "SFMC returned an error page";
}
var SfmcApiError = class extends Error {
	constructor(status, text) {
		super(`SFMC API error ${status}: ${errorText(text).substring(0, 300)}`);
		this.status = status;
	}
};
function isWebPage(text) {
	return /^\s*(<!DOCTYPE html|<html)/i.test(String(text ?? ""));
}
var needsSession = (res) => res.status === 401 || res.type === "opaqueredirect" || res.webPage;
function appInfo(app, stack) {
	const cloud = stack ? `https://mc.${stack}.exacttarget.com/cloud/` : null;
	if (!app) return {
		id: null,
		name: "Marketing Cloud",
		url: cloud
	};
	const url = stack && app.landings(stack).find((u) => u.includes(".exacttarget.com/cloud/")) || cloud;
	return {
		id: app.id,
		name: app.name,
		url
	};
}
async function send(url, method, body, headers) {
	const opts = {
		method,
		credentials: "include",
		redirect: "manual",
		headers: {
			"Content-Type": "application/json",
			...headers
		}
	};
	if (body != null) opts.body = typeof body === "string" ? body : JSON.stringify(body);
	try {
		const r = await fetch(url, opts);
		const body = await r.text().catch(() => "");
		return {
			ok: r.ok,
			status: r.status,
			type: r.type,
			headers: r.headers,
			body,
			webPage: r.ok && isWebPage(body)
		};
	} catch (err) {
		return {
			ok: false,
			status: 0,
			type: "error",
			headers: new Headers(),
			body: err.message,
			webPage: false
		};
	}
}
async function authHeaders({ url, stack, family, app, mutating }) {
	const headers = {};
	if (family === "mca" && stack && needsPageHeaders(url)) {
		let ph = pageHeadersFor(stack);
		if (!ph?.Authorization || mutating && !ph["X-CSRF-Token"]) ph = await capturePageHeaders(stack, { needCsrf: mutating }) || ph;
		if (ph?.Authorization) return { ...ph };
	}
	if (family === "core") {
		const csrf = mutating && getCoreCsrf(stack);
		if (csrf) headers["X-CSRF-Token"] = csrf;
	} else if (family === "mca") {
		if (app?.bearer) {
			const token = await getMcaToken(stack);
			if (token) headers.Authorization = `Bearer ${token}`;
		}
		if (mutating) {
			const csrf = await getAppCsrf(url, app?.csrfCookie || "_csrf");
			if (csrf) headers["X-CSRF-Token"] = csrf;
		}
	}
	return headers;
}
async function sfmcFetch(request) {
	const { stack, app } = resolveUrl(request.url);
	try {
		return await fetchWithSession(request);
	} catch (err) {
		if (err && typeof err === "object" && !err.app) err.app = appInfo(app, stack);
		throw err;
	}
}
async function fetchWithSession({ url, method = "GET", body = null, bootstrap = true }) {
	const target = {
		url,
		...resolveUrl(url),
		mutating: method !== "GET" && method !== "HEAD"
	};
	const { stack, family, app } = target;
	let headers = await authHeaders(target);
	let res = await send(url, method, body, headers);
	if (res.status === 403 && family === "mca" && headers["X-CSRF-Token"]) {
		if (needsPageHeaders(url) && headers["X-Requested-With"]) dropPageHeaders(stack);
		headers = await authHeaders(target);
		res = await send(url, method, body, headers);
	}
	if (needsSession(res) && app?.bearer && headers.Authorization) {
		dropMcaToken(stack);
		headers = await authHeaders(target);
		if (headers.Authorization) res = await send(url, method, body, headers);
	}
	if (needsSession(res) && app && stack && bootstrap) {
		await ensureSession(app, stack, { onLoggedOut: forgetStack });
		headers = await authHeaders(target);
		res = await send(url, method, body, headers);
	}
	if (res.webPage) throw new SfmcAuthError(SESSION_UNAVAILABLE, `${app?.name || "SFMC"} sent a web page (its login) instead of data, so it has no session.`);
	if (needsSession(res)) {
		await forgetStack(stack);
		throw new SfmcAuthError(LOGIN_REQUIRED, "SFMC session expired (401). Please log in to SFMC in any tab, then try again.");
	}
	const text = res.body;
	if (family === "core" && stack) {
		const fresh = res.headers?.get?.("x-csrf-token");
		if (fresh) rememberCsrf(stack, fresh);
	}
	if (!res.ok) throw new SfmcApiError(res.status, text);
	if (!text) return null;
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
}
//#endregion
//#region src/background/businessUnit.js
var cache$1 = {};
var TTL = 6e4;
function toBusinessUnit(d) {
	if (!d?.name) return null;
	return {
		name: d.name,
		accountId: d.accountId ?? d.id ?? d.memberId ?? null
	};
}
async function fetchCurrentBusinessUnit(stack) {
	const hit = cache$1[stack];
	if (hit && Date.now() - hit.ts < TTL) return hit.bu;
	const res = await fetch(`https://mc.${stack}.exacttarget.com/cloud/fuelapi/platform-internal/v1/accounts/@current`, {
		credentials: "include",
		redirect: "manual"
	});
	if (res.status !== 200) return null;
	const bu = toBusinessUnit(await res.json());
	cache$1[stack] = {
		ts: Date.now(),
		bu
	};
	return bu;
}
var QUERY_STUDIO_2_ORIGINS = ["https://querystudio2-dev-89f7e4653c61.herokuapp.com/*"];
var QUERY_STUDIO_CREATE_URLS = ["https://querystudio.herokuapp.com/query/create", ...QUERY_STUDIO_2_ORIGINS.map((o) => o.replace(/\*$/, "query/create"))];
function isQueryStudio2(url) {
	return QUERY_STUDIO_2_ORIGINS.some((o) => String(url || "").startsWith(o.replace(/\*$/, "")));
}
//#endregion
//#region src/background/capture.js
var decoder = new TextDecoder("utf-8");
async function blinkIcon() {
	try {
		chrome.action.setIcon({ path: "/images/icon48x48-off.png" });
		await delay(5e3);
		chrome.action.setIcon({ path: "/images/icon48x48.png" });
	} catch {}
}
async function saveRecords(records) {
	blinkIcon();
	await storageSet("local", records);
}
async function renameQuery(id, name) {
	const rec = (await storageGet("local", id))[id];
	if (rec) await storageSet("local", { [id]: {
		...rec,
		name
	} });
}
async function tagBusinessUnit(id) {
	try {
		const { stack } = await resolveStack();
		if (!stack) return;
		const bu = await fetchCurrentBusinessUnit(stack);
		if (!bu) return;
		const rec = (await storageGet("local", id))[id];
		if (!rec || rec.businessUnit?.name) return;
		await storageSet("local", { [id]: {
			...rec,
			businessUnit: {
				...rec.businessUnit || {},
				...bu
			}
		} });
	} catch (e) {
		console.warn("[Toolkit:SW] Could not tag the business unit:", e?.message);
	}
}
async function captureQueryStudio(details) {
	if (details.method !== "POST" || !details.requestBody?.raw?.[0]?.bytes) return;
	let queryText;
	try {
		queryText = JSON.parse(decoder.decode(new Uint8Array(details.requestBody.raw[0].bytes))).querytext;
	} catch {
		return;
	}
	if (!queryText) return;
	if (isQueryStudio2(details.url)) {
		if ((await storageGet("local", ["_saveQueryStudio2"]))["_saveQueryStudio2"] === false) return;
	}
	const ts = details.timeStamp;
	const id = "sql_" + ts;
	await saveRecords({ [id]: {
		id,
		queryText,
		timeStamp: ts,
		url: details.url,
		name: new Date(ts).toDateString() + " " + new Date(ts).toLocaleTimeString(),
		isFavourite: false
	} });
	await tagBusinessUnit(id);
}
var emailSaver = {
	enabled: true,
	debounceMs: 5e3
};
var lastSavedAt = {};
async function loadEmailSaverPrefs() {
	applyEmailSaverPrefs(await storageGet("local", ["_emailSaverEnabled", "_emailSaveDebounce"]));
}
function applyEmailSaverPrefs(prefs) {
	if ("_emailSaverEnabled" in prefs) emailSaver.enabled = prefs._emailSaverEnabled !== false;
	if ("_emailSaveDebounce" in prefs) {
		const s = prefs._emailSaveDebounce;
		emailSaver.debounceMs = typeof s === "number" && s >= 0 ? s * 1e3 : 5e3;
	}
}
function pickView(view) {
	if (!view) return null;
	return {
		content: view.content || null,
		superContent: view.superContent || null,
		design: view.design || null,
		slots: view.slots || null,
		blocks: view.blocks || null
	};
}
async function captureEmail(details) {
	if (!emailSaver.enabled || details.method !== "PUT") return;
	if (!details.requestBody?.raw?.[0]?.bytes) return;
	let jsonStr, asset;
	try {
		jsonStr = decoder.decode(new Uint8Array(details.requestBody.raw[0].bytes));
		asset = JSON.parse(jsonStr);
	} catch {
		return;
	}
	if (!(asset.assetType?.name || "").toLowerCase().includes("email")) return;
	const assetId = asset.id || Number(details.url.split("/").pop());
	const now = Date.now();
	if (emailSaver.debounceMs > 0 && now - (lastSavedAt[assetId] || 0) < emailSaver.debounceMs) return;
	lastSavedAt[assetId] = now;
	const key = `email_${assetId}`;
	const stack = details.url.match(/content-builder\.([^.]+)\.marketingcloudapps\.com/)?.[1] || null;
	const compileAsset = {
		superContent: asset.superContent || null,
		content: asset.content || null,
		design: asset.design || null,
		slots: asset.slots || null,
		blocks: asset.blocks || null,
		views: { html: pickView(asset.views?.html) }
	};
	const assetBody = JSON.parse(jsonStr);
	if (assetBody.views) assetBody.views = {
		...asset.views.subjectline ? { subjectline: asset.views.subjectline } : {},
		...asset.views.preheader ? { preheader: asset.views.preheader } : {},
		...asset.views.html ? { html: asset.views.html } : {}
	};
	delete assetBody.thumbnail;
	const subject = asset.views?.subjectline?.content || "";
	const version = {
		versionId: `v_${now}`,
		savedAt: now,
		subject,
		name: asset.name || `Email ${assetId}`,
		status: asset.status?.name || "Draft",
		categoryName: asset.category?.name || "",
		compileAsset,
		assetBody,
		stack
	};
	const prev = (await storageGet("local", key))[key];
	await saveRecords({ [key]: {
		id: key,
		assetId: Number(assetId),
		customerKey: asset.customerKey || "",
		name: asset.name || `Email ${assetId}`,
		assetTypeName: asset.assetType?.name || "",
		assetTypeDisplayName: asset.assetType?.displayName || "",
		status: asset.status?.name || "Draft",
		categoryId: asset.category?.id || null,
		categoryName: asset.category?.name || "",
		subject,
		compileAsset,
		ownerName: asset.owner?.name || "",
		ownerEmail: asset.owner?.email || "",
		memberId: asset.memberId || null,
		enterpriseId: asset.enterpriseId || null,
		createdDate: asset.createdDate || null,
		modifiedDate: asset.modifiedDate || null,
		isFavourite: prev?.isFavourite || false,
		timeStamp: prev?.timeStamp || now,
		versions: [version, ...Array.isArray(prev?.versions) ? prev.versions : []]
	} });
}
//#endregion
//#region src/background/analytics.js
var GA4_MEASUREMENT_ID = "G-KYHPC12MT9";
var GA4_API_SECRET = "AacKkgqYTri0uyyZm3Dqhw";
async function sendAnalyticsEvent({ clientId, name, params }) {
	if (!clientId || !name) return;
	try {
		await fetch(`https://www.google-analytics.com/mp/collect?measurement_id=${GA4_MEASUREMENT_ID}&api_secret=${GA4_API_SECRET}`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				client_id: clientId,
				events: [{
					name,
					params: {
						...params,
						app: "toolkit",
						extension_version: chrome.runtime.getManifest().version
					}
				}]
			})
		});
	} catch (e) {
		console.warn("[Toolkit:SW] Analytics send failed:", e.message);
	}
}
//#endregion
//#region src/utils/openTab.js
/** Tab properties that place a new tab right after `tab` in its window. */
function nextTo(tab, props = {}) {
	if (!tab || typeof tab.index !== "number") return { ...props };
	const out = {
		...props,
		index: tab.index + 1
	};
	if (tab.windowId !== void 0) out.windowId = tab.windowId;
	if (tab.id !== void 0) out.openerTabId = tab.id;
	return out;
}
//#endregion
//#region src/background/deepLinks.js
var WATCH_FOR = 18e4;
/** True when `now` is the stack's SFMC shell without the deep part of `wanted`. */
function lostDeepLink(wanted, now) {
	try {
		const w = new URL(wanted);
		const n = new URL(now);
		if (n.host !== w.host || !n.pathname.startsWith("/cloud")) return false;
		const want = decodeURIComponent(w.hash);
		const have = decodeURIComponent(n.hash);
		return want.length > 1 && have !== want && !have.startsWith(want);
	} catch {
		return false;
	}
}
function openSfmcLink(url, fromTab = null) {
	return new Promise((resolve) => {
		let tabId = null;
		let restored = false;
		let leftShell = false;
		const stop = () => {
			try {
				chrome.tabs.onUpdated.removeListener(onUpdated);
			} catch {}
		};
		const onUpdated = (id, info, tab) => {
			if (id !== tabId || restored) return;
			const now = info.url || tab?.url || "";
			if (!now) return;
			if (!now.startsWith(url) && !lostDeepLink(url, now)) leftShell = true;
			if (info.status === "complete" && lostDeepLink(url, tab?.url || now) && (leftShell || tab?.url !== url)) {
				restored = true;
				stop();
				chrome.tabs.update(id, { url }, () => void chrome.runtime.lastError);
			}
		};
		try {
			chrome.tabs.onUpdated.addListener(onUpdated);
			chrome.tabs.create(nextTo(fromTab, { url }), (tab) => {
				if (chrome.runtime.lastError || !tab) {
					stop();
					resolve({ ok: false });
					return;
				}
				tabId = tab.id;
				setTimeout(stop, WATCH_FOR);
				resolve({ ok: true });
			});
		} catch {
			stop();
			resolve({ ok: false });
		}
	});
}
//#endregion
//#region src/background/updates.js
var UPDATE_KEY = "_updateAvailable";
function note(version) {
	if (version) chrome.storage.local.set({ [UPDATE_KEY]: {
		version,
		at: Date.now()
	} });
}
function watchForUpdates() {
	chrome.runtime.onUpdateAvailable?.addListener((details) => note(details?.version));
	chrome.runtime.onInstalled?.addListener(() => chrome.storage.local.remove(UPDATE_KEY));
	try {
		chrome.runtime.requestUpdateCheck?.((status, details) => {
			chrome.runtime.lastError;
			if (status === "update_available") note(details?.version);
		});
	} catch {}
}
//#endregion
//#region src/utils/watches.js
var WATCHES_KEY = "toolkit_watches";
var NOTICES_KEY = "toolkit_watch_notices";
var NOTIFY_KEY = "toolkit_watch_desktop";
var DEFAULT_ON = {
	paused: true,
	activated: true,
	runs: false,
	fails: true
};
var JOURNEY_DEFAULT_ON = {
	paused: true,
	activated: true,
	edited: false
};
var watchType = (w) => w?.type === "journey" ? "journey" : "automation";
var STATUS_NAMES = {
	"-1": "Error",
	0: "Build error",
	1: "Building",
	2: "Ready",
	3: "Running",
	4: "Paused",
	5: "Stopped",
	6: "Scheduled",
	7: "Awaiting trigger",
	8: "Inactive trigger"
};
function automationStatusName(v) {
	if (v == null || v === "") return "";
	const n = Number(v);
	if (Number.isInteger(n) && String(n) === String(v).trim() && STATUS_NAMES[n] != null) return STATUS_NAMES[n];
	return String(v);
}
var isPausedLike = (s) => /^(paused|stopped)$/i.test(s);
var isActiveLike = (s) => /^(scheduled|awaiting trigger|running)$/i.test(s);
var isFailure = (s) => /error|fail/i.test(String(s || ""));
var time$1 = (v) => {
	const t = Date.parse(v || "");
	return Number.isNaN(t) ? 0 : t;
};
/**
* Notices for the change from `prev` to `cur` ({ status, lastRunTime, lastRunStatus }),
* for the kinds switched on in `on`. No notices without a previous snapshot.
*/
function diffAutomation(prev, cur, on = DEFAULT_ON) {
	if (!prev || !cur) return [];
	const out = [];
	const was = automationStatusName(prev.status);
	const now = automationStatusName(cur.status);
	if (now && was && now !== was) {
		if (isPausedLike(now) && on.paused) out.push({
			kind: "paused",
			text: `is now ${now} (was ${was})`
		});
		else if (isActiveLike(now) && !isActiveLike(was) && on.activated) out.push({
			kind: "activated",
			text: `is now ${now} (was ${was})`
		});
	}
	if (time$1(cur.lastRunTime) > time$1(prev.lastRunTime)) {
		if (isFailure(cur.lastRunStatus) && on.fails) out.push({
			kind: "fails",
			text: `run failed${cur.lastRunStatus ? ` (${cur.lastRunStatus})` : ""}`
		});
		else if (on.runs) out.push({
			kind: "runs",
			text: `ran${cur.lastRunStatus ? `: ${cur.lastRunStatus}` : ""}`
		});
	}
	return out;
}
/** What a journey watch compares: status, version and last change. */
var journeySnapshot = (j) => ({
	status: j?.status ?? null,
	version: j?.version ?? null,
	modifiedDate: j?.modifiedDate ?? null
});
/** Notices for a journey's change from `prev` to `cur` ({ status, version, modifiedDate }). */
function diffJourney(prev, cur, on = JOURNEY_DEFAULT_ON) {
	if (!prev || !cur) return [];
	const out = [];
	const was = String(prev.status || "");
	const now = String(cur.status || "");
	if (now && was && now !== was) {
		if (/^(paused|stopped)$/i.test(now) && on.paused) out.push({
			kind: "paused",
			text: `is now ${now} (was ${was})`
		});
		else if (/^published$/i.test(now) && on.activated) out.push({
			kind: "activated",
			text: `is now ${now} (was ${was})`
		});
	}
	if (on.edited) {
		if (Number(cur.version) > Number(prev.version)) out.push({
			kind: "edited",
			text: `has a new version (${cur.version}, was ${prev.version})`
		});
		else if (cur.modifiedDate && prev.modifiedDate && time$1(cur.modifiedDate) > time$1(prev.modifiedDate)) out.push({
			kind: "edited",
			text: "was changed"
		});
	}
	return out;
}
/** Adds notices (newest first), keeping at most MAX_NOTICES. */
function addNotices(list, watch, changes, now = Date.now()) {
	const target = watchType(watch) === "journey" ? {
		type: "journey",
		journeyId: watch.id
	} : { automationId: watch.id };
	return [...changes.map((c, i) => ({
		id: `${now.toString(36)}${i}${Math.random().toString(36).slice(2, 6)}`,
		at: now,
		stack: watch.stack,
		...target,
		name: watch.name,
		kind: c.kind,
		text: c.text,
		read: false
	})), ...Array.isArray(list) ? list : []].slice(0, 50);
}
var unreadCount = (list) => Array.isArray(list) ? list.filter((n) => !n.read).length : 0;
//#endregion
//#region src/background/watches.js
var AS$1 = (stack) => `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi`;
var JB$1 = (stack) => `https://jbinteractions.${stack}.marketingcloudapps.com/fuelapi/interaction/v1`;
var CHECKED_KEY = "toolkit_watch_checked";
var PAGE_INTERVAL = 9e5;
var running$1 = /* @__PURE__ */ new Set();
async function journeySnap(stack, w) {
	const d = await sfmcFetch({ url: `${JB$1(stack)}/interactions/${w.key ? `key:${encodeURIComponent(w.key)}` : encodeURIComponent(w.id)}` });
	return {
		...journeySnapshot(d),
		name: d?.name || w.name,
		id: d?.id || w.id
	};
}
async function snapshot(stack, w) {
	const d = await sfmcFetch({ url: `${AS$1(stack)}/automation/v1/automations/${encodeURIComponent(w.id)}` });
	const snap = {
		status: d?.status ?? null,
		lastRunTime: d?.lastRunTime ?? null,
		lastRunStatus: d?.lastRunStatus ?? null,
		name: d?.name || w.name
	};
	if (snap.lastRunTime && snap.lastRunTime !== w.last?.lastRunTime && !snap.lastRunStatus) try {
		const day = (t) => new Date(t).toISOString().slice(0, 10);
		const runs = await sfmcFetch({ url: `${AS$1(stack)}/legacy/v1/beta/automations/automation/instance/?definition_id=${encodeURIComponent(w.id)}&$top=1&begin_date=${day(Date.now() - 6048e5)}&end_date=${day(Date.now())}&order_by=${encodeURIComponent("StartTime desc")}&to_server_time=1` });
		const r = (runs?.entry || runs?.items || [])[0];
		snap.lastRunStatus = r?.status ?? r?.statusName ?? r?.StatusName ?? null;
	} catch {}
	return snap;
}
async function updateBadge(list) {
	const n = unreadCount(list ?? (await storageGet("local", ["toolkit_watch_notices"]))["toolkit_watch_notices"]);
	try {
		await chrome.action?.setBadgeText?.({ text: n ? String(Math.min(n, 99)) : "" });
		if (n) await chrome.action?.setBadgeBackgroundColor?.({ color: "#d03b3b" });
	} catch {}
}
/** Checks the stack's watched automations; `force` skips the 15-minute wait. Returns { checked, notices }. */
async function checkWatches(stack, { force = false } = {}) {
	if (!stack || running$1.has(stack)) return {
		checked: 0,
		notices: 0
	};
	const store = await storageGet("local", [
		WATCHES_KEY,
		NOTICES_KEY,
		CHECKED_KEY,
		NOTIFY_KEY
	]);
	const watches = store["toolkit_watches"] || {};
	const mine = Object.entries(watches).filter(([, w]) => w.stack === stack);
	const checkedAt = store[CHECKED_KEY] || {};
	if (!mine.length || !force && Date.now() - (checkedAt[stack] || 0) < PAGE_INTERVAL) return {
		checked: 0,
		notices: 0
	};
	running$1.add(stack);
	try {
		let notices = store["toolkit_watch_notices"] || [];
		const fresh = [];
		for (const [k, w] of mine) try {
			if (watchType(w) === "journey") {
				const cur = await journeySnap(stack, w);
				const changes = diffJourney(w.last, cur, w.on);
				const watch = {
					...w,
					name: cur.name,
					id: cur.id
				};
				if (changes.length) {
					notices = addNotices(notices, watch, changes);
					fresh.push(...changes.map((c) => `${cur.name} ${c.text}`));
				}
				watches[k] = {
					...w,
					name: cur.name,
					latestId: cur.id,
					last: journeySnapshot(cur),
					checkedAt: Date.now(),
					error: void 0
				};
				continue;
			}
			const cur = await snapshot(stack, w);
			const changes = diffAutomation(w.last, cur, w.on);
			if (changes.length) {
				notices = addNotices(notices, {
					...w,
					name: cur.name
				}, changes);
				fresh.push(...changes.map((c) => `${cur.name} ${c.text}`));
			}
			watches[k] = {
				...w,
				name: cur.name,
				last: {
					status: cur.status,
					statusName: automationStatusName(cur.status),
					lastRunTime: cur.lastRunTime,
					lastRunStatus: cur.lastRunStatus
				},
				checkedAt: Date.now()
			};
		} catch (e) {
			watches[k] = {
				...w,
				error: e?.message || String(e),
				checkedAt: Date.now()
			};
		}
		await chrome.storage.local.set({
			[WATCHES_KEY]: watches,
			[NOTICES_KEY]: notices,
			[CHECKED_KEY]: {
				...checkedAt,
				[stack]: Date.now()
			}
		});
		await updateBadge(notices);
		if (fresh.length && store["toolkit_watch_desktop"] && chrome.notifications?.create) chrome.notifications.create({
			type: "basic",
			iconUrl: chrome.runtime.getURL("images/icon128x128.png"),
			title: "Marketing Cloud Toolkit: watched automations and journeys",
			message: fresh.slice(0, 3).join("\n") + (fresh.length > 3 ? `\n+${fresh.length - 3} more` : "")
		});
		return {
			checked: mine.length,
			notices: fresh.length
		};
	} finally {
		running$1.delete(stack);
	}
}
//#endregion
//#region src/utils/summaries.js
var time = (v) => {
	const t = Date.parse(v || "");
	return Number.isNaN(t) ? 0 : t;
};
function countBy(list, keyOf) {
	const m = /* @__PURE__ */ new Map();
	for (const x of list) {
		const k = keyOf(x) || "Unknown";
		m.set(k, (m.get(k) || 0) + 1);
	}
	return [...m].map(([label, count]) => ({
		label,
		count
	})).sort((a, b) => b.count - a.count);
}
var RUNNING_TOO_LONG = 216e5;
/** Counts by status and last run, and the automations that need a look. */
function summarizeAutomations(list, now = Date.now()) {
	const status = (a) => automationStatusName(a.status);
	const attention = [];
	for (const a of list) {
		const s = status(a);
		if (isFailure(a.lastRunStatus)) attention.push({
			automation: a,
			reason: `Last run: ${a.lastRunStatus}`
		});
		else if (/error/i.test(s)) attention.push({
			automation: a,
			reason: `Status: ${s}`
		});
		else if (/^running$/i.test(s) && a.lastRunTime && now - time(a.lastRunTime) > RUNNING_TOO_LONG) attention.push({
			automation: a,
			reason: "Running for more than 6 hours"
		});
	}
	attention.sort((x, y) => time(y.automation.lastRunTime) - time(x.automation.lastRunTime));
	return {
		total: list.length,
		byStatus: countBy(list, status),
		byLastRun: countBy(list.filter((a) => a.lastRunStatus), (a) => String(a.lastRunStatus)),
		failedLastRun: list.filter((a) => isFailure(a.lastRunStatus)).length,
		attention
	};
}
var LIVE_JOURNEY = /^(published|running|scheduledtopublish)$/i;
function summarizeJourneys(list) {
	return {
		total: list.length,
		byStatus: countBy(list, (j) => j.status),
		live: list.filter((j) => LIVE_JOURNEY.test(j.status || "")).length
	};
}
//#endregion
//#region src/background/dashboard.js
var AS = (stack) => `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi`;
var JB = (stack) => `https://jbinteractions.${stack}.marketingcloudapps.com/fuelapi/interaction/v1`;
var PAGE = 50;
var MAX_ITEMS = 2e3;
var KEEP = 6e5;
var cache = /* @__PURE__ */ new Map();
var running = /* @__PURE__ */ new Map();
async function currentBU(stack) {
	try {
		const d = await sfmcFetch({ url: `https://mc.${stack}.exacttarget.com/cloud/fuelapi/platform-internal/v1/accounts/@current` });
		return {
			id: d?.accountId ?? d?.id ?? d?.memberId ?? "",
			name: d?.name || ""
		};
	} catch {
		return {
			id: "",
			name: ""
		};
	}
}
async function automationPage(stack, skip, top) {
	const d = await sfmcFetch({ url: `${AS(stack)}/legacy/v1/beta/automations/automation/definition/?$top=${top}&$skip=${skip}&$sort=${encodeURIComponent("lastRunTime desc")}&view=gridView` });
	return {
		entries: d?.entry || [],
		total: d?.totalResults ?? (d?.entry || []).length
	};
}
/** Every automation (up to 2,000), 50 at a time, as the overview reads them (feedback #28's fallback included). */
async function listAutomations(stack) {
	const first = await automationPage(stack, 0, PAGE);
	const items = [...first.entries];
	const seen = new Set(items.map((a) => a.id));
	let total = first.total;
	while (items.length < Math.min(total, MAX_ITEMS)) {
		let r = await automationPage(stack, items.length, PAGE);
		let fresh = r.entries.filter((a) => !seen.has(a.id));
		if (!fresh.length) {
			r = await automationPage(stack, 0, items.length + PAGE);
			fresh = r.entries.filter((a) => !seen.has(a.id));
		}
		if (!fresh.length) break;
		fresh.forEach((a) => {
			seen.add(a.id);
			items.push(a);
		});
		total = r.total;
	}
	return items;
}
/** Every journey's latest version (up to 2,000). */
async function listJourneys(stack) {
	const items = [];
	for (let page = 1; items.length < MAX_ITEMS; page++) {
		const params = new URLSearchParams({
			$page: String(page),
			$pageSize: String(PAGE),
			$orderBy: "ModifiedDate DESC",
			mostRecentVersionOnly: "true"
		});
		const d = await sfmcFetch({ url: `${JB(stack)}/interactions?${params}` });
		const got = d?.items || [];
		items.push(...got);
		if (got.length < PAGE || items.length >= (d?.count ?? Infinity)) break;
	}
	return items;
}
/** What the card shows: plain data only (names, counts, ids for links). */
function dashboardSummary(automations, journeys, watches, stack, now = Date.now()) {
	const a = automations ? summarizeAutomations(automations, now) : null;
	const j = journeys ? summarizeJourneys(journeys) : null;
	const watched = Object.values(watches || {}).filter((w) => w.stack === stack).map((w) => ({
		type: watchType(w),
		id: w.id,
		name: w.name || w.id,
		status: watchType(w) === "journey" ? w.last?.status || "" : automationStatusName(w.last?.status),
		lastRunStatus: w.last?.lastRunStatus || ""
	}));
	return {
		at: now,
		automations: a && {
			total: a.total,
			failedLastRun: a.failedLastRun,
			byStatus: a.byStatus,
			attention: a.attention.slice(0, 5).map((x) => ({
				id: x.automation.id,
				name: x.automation.name,
				reason: x.reason
			})),
			attentionCount: a.attention.length
		},
		journeys: j && {
			total: j.total,
			live: j.live,
			byStatus: j.byStatus
		},
		watched
	};
}
async function build(stack, bu) {
	const [automations, journeys, store] = await Promise.all([
		listAutomations(stack).catch((e) => ({ error: e.message })),
		listJourneys(stack).catch((e) => ({ error: e.message })),
		storageGet("local", [WATCHES_KEY])
	]);
	const summary = dashboardSummary(Array.isArray(automations) ? automations : null, Array.isArray(journeys) ? journeys : null, store[WATCHES_KEY], stack);
	summary.businessUnit = bu.name;
	summary.errors = {
		automations: Array.isArray(automations) ? null : automations.error,
		journeys: Array.isArray(journeys) ? null : journeys.error
	};
	return summary;
}
/** The summary for `stack`: from the last 10 minutes unless `force`. */
async function getDashboardSummary(stack, { force = false } = {}) {
	if (!/^s\d+$/i.test(stack || "")) throw new Error("No SFMC stack.");
	const bu = await currentBU(stack);
	const key = `${stack}:${bu.id}`;
	const hit = cache.get(key);
	if (!force && hit && Date.now() - hit.at < KEEP) return hit.summary;
	if (!running.has(key)) running.set(key, build(stack, bu).then((summary) => {
		if (!summary.errors.automations || !summary.errors.journeys) cache.set(key, {
			at: Date.now(),
			summary
		});
		return summary;
	}).finally(() => running.delete(key)));
	return running.get(key);
}
//#endregion
//#region src/utils/activityVersions.js
var ACTIVITY_SAVER_SETTING = "_activitySaverEnabled";
var ACTIVITY_MAX_SETTING = "_activityMaxVersions";
var KINDS = {
	query: {
		segment: "queries",
		contentField: "queryText",
		idField: "queryDefinitionId",
		label: "SQL Query"
	},
	script: {
		segment: "scripts",
		contentField: "script",
		idField: "ssjsActivityId",
		label: "Script"
	}
};
var recordKey = (kind, id) => `activity_${kind}_${String(id).toLowerCase()}`;
var ID = "[0-9a-zA-Z-]{6,}";
var VERBS = /* @__PURE__ */ new Set([
	"validate",
	"validation",
	"run",
	"start",
	"stop",
	"pause",
	"perform",
	"actions",
	"action",
	"search",
	"copy",
	"preview",
	"test",
	"execute",
	"status",
	"create",
	"update",
	"delete",
	"list",
	"query",
	"queries",
	"script",
	"scripts"
]);
/** Whether a path segment looks like an activity id: a GUID, or has a digit and is not a known verb. */
function looksLikeActivityId(id) {
	const s = String(id || "");
	if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s)) return true;
	return s.length >= 6 && /\d/.test(s) && /^[0-9a-zA-Z-]+$/.test(s) && !VERBS.has(s.toLowerCase());
}
var QUERY_SEGMENTS = [
	"queries",
	"query",
	"queryactivities",
	"querydefinitions",
	"querydefinition"
];
var SCRIPT_SEGMENTS = [
	"scripts",
	"script",
	"ssjs",
	"ssjsactivities",
	"ssjsactivity",
	"scriptactivities"
];
var SAVE_RE = new RegExp(`^https://[^/]+\\.([^./]+)\\.(?:marketingcloudapps|exacttarget)\\.com/(?:[^?#]*/)?AutomationStudioFuel3/(?:[^?#]*/)?(${[...QUERY_SEGMENTS, ...SCRIPT_SEGMENTS].join("|")})/(${ID})/?(?:[?#].*)?$`, "i");
var WRITE_METHODS = /* @__PURE__ */ new Set([
	"PATCH",
	"PUT",
	"POST"
]);
/** { kind, id, stack } for an Automation Studio save of a query or script, else null. */
function matchActivitySave(url, method) {
	if (!WRITE_METHODS.has(String(method || "").toUpperCase())) return null;
	const m = String(url || "").match(SAVE_RE);
	if (!m || !looksLikeActivityId(m[3])) return null;
	return {
		kind: QUERY_SEGMENTS.includes(m[2].toLowerCase()) ? "query" : "script",
		id: m[3],
		stack: m[1].toLowerCase()
	};
}
var ACTIVITY_LOG_KEY = "toolkit_activityRequestLog";
var LOG_HOST = /^https:\/\/[^/]+\.(?:marketingcloudapps|exacttarget)\.com\//i;
var LOG_PATH = /automationstudio|automation|script|ssjs|quer/i;
/** Whether a request belongs in the diagnostic log: it writes, on an SFMC host, on a relevant path. */
function isLoggedActivityRequest(url, method) {
	const m = String(method || "").toUpperCase();
	if (!m || m === "GET" || m === "HEAD" || m === "OPTIONS") return false;
	const u = String(url || "");
	if (!LOG_HOST.test(u)) return false;
	return LOG_PATH.test(u.split(/[?#]/)[0]);
}
/** The URL with every query value removed (names kept), so no token is ever logged. */
function logSafeUrl(url) {
	const u = String(url || "").split("#")[0];
	const i = u.indexOf("?");
	if (i < 0) return u;
	const names = u.slice(i + 1).split("&").filter(Boolean).map((p) => decodeURIComponentSafe(p.split("=")[0]));
	return `${u.slice(0, i)}?${names.map((n) => `${n}=…`).join("&")}`;
}
function decodeURIComponentSafe(s) {
	try {
		return decodeURIComponent(s);
	} catch {
		return s;
	}
}
/** Top-level keys of a JSON body (at most 40), or null when there is none. */
function bodyKeys(body) {
	if (!body || typeof body !== "object") return null;
	return (Array.isArray(body) ? ["(array)"] : Object.keys(body)).slice(0, 40);
}
/** The log with `entry` added first, at most `max` entries. */
function addLogEntry(log, entry, max = 25) {
	return [entry, ...Array.isArray(log) ? log : []].slice(0, max);
}
/** The JSON body of a webRequest requestBody (raw bytes or form fields), or null. */
function decodeRequestBody(requestBody) {
	try {
		if (requestBody?.raw?.length) {
			const parts = requestBody.raw.filter((p) => p?.bytes).map((p) => new Uint8Array(p.bytes));
			const size = parts.reduce((n, p) => n + p.length, 0);
			const all = new Uint8Array(size);
			let at = 0;
			for (const p of parts) {
				all.set(p, at);
				at += p.length;
			}
			const parsed = JSON.parse(new TextDecoder("utf-8").decode(all));
			return parsed && typeof parsed === "object" ? parsed : null;
		}
		if (requestBody?.formData) {
			const f = requestBody.formData;
			const one = (k) => Array.isArray(f[k]) ? f[k][0] : f[k];
			return Object.fromEntries(Object.keys(f).map((k) => [k, one(k)]));
		}
	} catch {}
	return null;
}
var UPDATE_TYPES = {
	0: "Overwrite",
	1: "Update",
	2: "Append"
};
/**
* The fields worth keeping from a query or script object (a save body or the GET of
* the activity). Returns null when it holds no SQL or script.
*/
function pickActivity(kind, obj) {
	if (!obj || typeof obj !== "object" || !KINDS[kind]) return null;
	const cf = KINDS[kind].contentField;
	const o = typeof obj[cf] === "string" ? obj : [obj[kind], obj.definition].find((w) => w && typeof w[cf] === "string") || obj;
	const content = o[KINDS[kind].contentField];
	if (typeof content !== "string") return null;
	const out = {
		name: typeof o.name === "string" ? o.name : "",
		key: o.key || o.customerKey || "",
		content
	};
	if (kind === "query") {
		out.targetName = o.targetName || o.targetDataExtensionName || "";
		out.targetKey = o.targetKey || "";
		const t = o.targetUpdateTypeName ?? UPDATE_TYPES[o.targetUpdateTypeId];
		out.targetUpdateType = typeof t === "string" ? t : "";
	}
	return out;
}
var sameField = (x, y) => !x || !y || x === y;
var sameContent = (a, b) => !!a && !!b && a.content === b.content && sameField(a.name, b.name) && sameField(a.targetName, b.targetName) && sameField(a.targetUpdateType, b.targetUpdateType);
/**
* Adds versions (oldest first in `incoming`) to a record. A version identical to the
* newest stored one is skipped. At most `max` versions are kept (newest first).
* Returns the new versions array and how many were added.
*/
function addVersions(existing, incoming, max = 50) {
	const versions = Array.isArray(existing) ? [...existing] : [];
	let added = 0;
	for (const v of incoming) {
		if (!v || typeof v.content !== "string") continue;
		if (sameContent(versions[0], v)) continue;
		versions.unshift(v);
		added++;
	}
	const limit = Number.isFinite(Number(max)) && Number(max) > 0 ? Math.floor(Number(max)) : 50;
	return {
		versions: versions.slice(0, limit),
		added
	};
}
function makeVersion(picked, { savedAt, source, stack }) {
	return {
		versionId: `v_${savedAt}_${source === "before-save" ? "b" : "s"}`,
		savedAt,
		source,
		stack: stack || null,
		...picked
	};
}
/** Where to read (GET) or write back (PATCH) one activity through Automation Studio. */
function activityUrl(kind, stack, id) {
	return `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi/automation/v1/${KINDS[kind].segment}/${encodeURIComponent(id)}`;
}
//#endregion
//#region src/background/activityCapture.js
var queues = {};
var captureTiming = { beforeReadMs: 1e4 };
function withTimeout(promise, ms) {
	let timer;
	return Promise.race([promise, new Promise((resolve) => {
		timer = setTimeout(() => {
			console.warn("[Toolkit:SW] Reading the activity before its save took too long; keeping the saved version only.");
			resolve(null);
		}, ms);
	})]).finally(() => clearTimeout(timer));
}
var pendingSaves = {};
var completeTiming = { waitMs: 6e4 };
function waitForCompletion(requestId) {
	return new Promise((resolve) => {
		const timer = setTimeout(() => {
			delete pendingSaves[requestId];
			resolve(false);
		}, completeTiming.waitMs);
		pendingSaves[requestId] = (ok) => {
			clearTimeout(timer);
			delete pendingSaves[requestId];
			resolve(ok);
		};
	});
}
function activitySaveCompleted(details) {
	const done = pendingSaves[details?.requestId];
	if (done) done(!details.error && details.statusCode >= 200 && details.statusCode < 300);
}
function captureActivity(details) {
	const hit = matchActivitySave(details?.url, details?.method);
	if (!hit) return;
	const body = decodeRequestBody(details.requestBody);
	let saved = pickActivity(hit.kind, body);
	if (!saved && body) return;
	const url = activityUrl(hit.kind, hit.stack, hit.id);
	const savedLater = saved ? null : waitForCompletion(details.requestId).then((ok) => {
		if (!ok) return null;
		return sfmcFetch({ url }).then((o) => pickActivity(hit.kind, o)).catch((e) => {
			console.warn("[Toolkit:SW] Could not read the activity after its save:", e?.message);
			return null;
		});
	});
	const before = withTimeout(sfmcFetch({ url }).catch((e) => {
		console.warn("[Toolkit:SW] Could not read the activity before its save:", e?.message);
		return null;
	}), captureTiming.beforeReadMs);
	const key = recordKey(hit.kind, hit.id);
	const savedAt = details.timeStamp || Date.now();
	const run = (queues[key] || Promise.resolve()).then(async () => {
		if (!saved) saved = await savedLater;
		if (saved) await store(hit, key, saved, before, savedAt);
	});
	queues[key] = run.catch(() => {});
	return run;
}
async function store(hit, key, saved, beforePromise, savedAt) {
	const prefs = await storageGet("local", [
		ACTIVITY_SAVER_SETTING,
		ACTIVITY_MAX_SETTING,
		key
	]);
	if (prefs["_activitySaverEnabled"] === false) return;
	const beforeObj = pickActivity(hit.kind, await beforePromise);
	const incoming = [];
	if (beforeObj) incoming.push(makeVersion(beforeObj, {
		savedAt: savedAt - 1,
		source: "before-save",
		stack: hit.stack
	}));
	incoming.push(makeVersion(saved, {
		savedAt,
		source: "saved",
		stack: hit.stack
	}));
	const prev = prefs[key];
	const { versions, added } = addVersions(prev?.versions, incoming, prefs["_activityMaxVersions"] ?? 50);
	if (!added) return;
	const latest = versions[0];
	await storageSet("local", { [key]: {
		id: key,
		kind: hit.kind,
		activityId: hit.id,
		name: latest.name || prev?.name || "",
		key: latest.key || prev?.key || "",
		stack: hit.stack,
		businessUnit: prev?.businessUnit || null,
		timeStamp: prev?.timeStamp || savedAt,
		versions
	} });
	console.info(`[Toolkit:SW] Saved ${added} version(s) of ${hit.kind} "${latest.name || hit.id}" (${key})`);
	if (!prev?.businessUnit) tagActivityBusinessUnit(key, hit.stack);
}
async function tagActivityBusinessUnit(key, stack) {
	try {
		const bu = await fetchCurrentBusinessUnit(stack);
		if (!bu) return;
		const rec = (await storageGet("local", key))[key];
		if (!rec || rec.businessUnit?.name) return;
		await storageSet("local", { [key]: {
			...rec,
			businessUnit: bu
		} });
	} catch (e) {
		console.warn("[Toolkit:SW] Could not tag the business unit:", e?.message);
	}
}
var logWrite = Promise.resolve();
var logged = /* @__PURE__ */ new Set();
function updateLog(change) {
	logWrite = logWrite.then(async () => {
		const log = (await storageGet("session", "toolkit_activityRequestLog"))["toolkit_activityRequestLog"] || [];
		await storageSet("session", { [ACTIVITY_LOG_KEY]: change(log) });
	}).catch((e) => console.warn("[Toolkit:SW] Could not update the Automation Studio request log:", e?.message));
	return logWrite;
}
function logActivityRequest(details) {
	if (!details || details.tabId === -1) return;
	if (!isLoggedActivityRequest(details.url, details.method)) return;
	const body = decodeRequestBody(details.requestBody);
	const hasBody = !!(details.requestBody?.raw?.length || details.requestBody?.formData);
	const hit = matchActivitySave(details.url, details.method);
	logged.add(details.requestId);
	if (logged.size > 100) logged.delete(logged.values().next().value);
	return updateLog((log) => addLogEntry(log, {
		requestId: details.requestId,
		at: details.timeStamp || Date.now(),
		method: String(details.method || "").toUpperCase(),
		url: logSafeUrl(details.url),
		status: null,
		matched: hit ? {
			kind: hit.kind,
			id: hit.id
		} : null,
		hasBody,
		keys: bodyKeys(body)
	}));
}
function logActivityRequestDone(details) {
	if (!details || !logged.has(details.requestId)) return;
	logged.delete(details.requestId);
	const status = details.error ? `failed: ${details.error}` : details.statusCode;
	return updateLog((log) => log.map((e) => e.requestId === details.requestId ? {
		...e,
		status
	} : e));
}
//#endregion
//#region src/background/index.js
onForgetStack(dropMcaToken);
setOnMintFailure(forgetStack);
restoreCsrfTokens();
restorePageHeaders();
loadEmailSaverPrefs();
watchForUpdates();
updateBadge();
var APP_PAGE = "app.html";
chrome.action?.onClicked?.addListener((tab) => {
	createTab(nextTo(tab, { url: chrome.runtime.getURL(APP_PAGE) }));
});
chrome.tabs?.onActivated?.addListener(({ tabId }) => {
	chrome.tabs.get(tabId, (tab) => {
		if (!chrome.runtime.lastError && tab) rememberActiveStack(tab.url, tab.id);
	});
});
chrome.tabs?.onUpdated?.addListener((tabId, info, tab) => {
	if (info.status === "complete" && tab?.active) rememberActiveStack(tab.url, tab.id);
});
chrome.storage?.onChanged?.addListener((changes, area) => {
	if (area !== "local") return;
	const prefs = {};
	for (const k of ["_emailSaverEnabled", "_emailSaveDebounce"]) if (k in changes) prefs[k] = changes[k].newValue;
	applyEmailSaverPrefs(prefs);
});
chrome.webRequest?.onBeforeRequest.addListener(noteRequestStack, { urls: ["https://*.exacttarget.com/*", "https://*.marketingcloudapps.com/*"] });
chrome.webRequest?.onBeforeSendHeaders.addListener(sniffCsrf, { urls: ["https://*.exacttarget.com/*"] }, ["requestHeaders", "extraHeaders"]);
chrome.webRequest?.onBeforeSendHeaders.addListener(sniffPageHeaders, { urls: ["https://*.marketingcloudapps.com/contactsmeta/*"] }, ["requestHeaders", "extraHeaders"]);
chrome.webRequest?.onBeforeRequest.addListener(captureQueryStudio, { urls: QUERY_STUDIO_CREATE_URLS }, ["requestBody"]);
chrome.webRequest?.onBeforeRequest.addListener(captureEmail, { urls: ["https://*.marketingcloudapps.com/fuelapi/asset/v1/content/assets/*"] }, ["requestBody"]);
var ACTIVITY_URLS = ["https://*.marketingcloudapps.com/AutomationStudioFuel3/*", "https://*.exacttarget.com/*AutomationStudioFuel3/*"];
chrome.webRequest?.onBeforeRequest.addListener(captureActivity, { urls: ACTIVITY_URLS }, ["requestBody"]);
chrome.webRequest?.onCompleted?.addListener(activitySaveCompleted, { urls: ACTIVITY_URLS });
chrome.webRequest?.onErrorOccurred?.addListener(activitySaveCompleted, { urls: ACTIVITY_URLS });
var SFMC_REQUEST_URLS = ["https://*.marketingcloudapps.com/*", "https://*.exacttarget.com/*"];
chrome.webRequest?.onBeforeRequest.addListener(logActivityRequest, { urls: SFMC_REQUEST_URLS }, ["requestBody"]);
chrome.webRequest?.onCompleted?.addListener(logActivityRequestDone, { urls: SFMC_REQUEST_URLS });
chrome.webRequest?.onErrorOccurred?.addListener(logActivityRequestDone, { urls: SFMC_REQUEST_URLS });
var isSfmcUrl = (u) => /^https:\/\/[^/]*\.(exacttarget|marketingcloudapps|marketingcloud|salesforce-marketingcloud)\.com\//.test(u || "");
var isLoggedInUrl = (u) => !u.includes("/login") && !u.includes("mc.login.") && !u.includes("sso");
async function connectionStatus() {
	const { stack } = await resolveAndPublish();
	if (stack && !isMcaTokenReady(stack) && !mintBackoff(stack)) getMcaToken(stack);
	let coreOpen = false;
	let contentBuilderOpen = false;
	for (const t of await queryTabs({})) {
		const u = t.url || "";
		if (!isSfmcUrl(u) || !isLoggedInUrl(u)) continue;
		if (u.includes("content-builder.")) contentBuilderOpen = true;
		else if (u.includes("mc.") || u.includes("members.")) coreOpen = true;
	}
	return {
		stack,
		connected: !!stack,
		tokenReady: !!getCoreCsrf(stack),
		mcaTokenReady: isMcaTokenReady(stack),
		areas: {
			core: { open: coreOpen },
			contentBuilder: { open: contentBuilderOpen }
		}
	};
}
function errorReply(err) {
	return {
		error: err?.message || String(err),
		code: err?.code || null,
		status: err?.status ?? null,
		app: err?.app || null
	};
}
var handlers = {
	PING: () => ({ ok: true }),
	GET_SESSION: (m) => getSession(m.stackKey),
	GET_STACKS: () => getStacks(),
	SET_STACK_OVERRIDE: (m) => setStackOverride(m.stack),
	GET_CONNECTION_STATUS: () => connectionStatus(),
	SFMC_SESSION_STATUS: async (m) => ({ status: await sessionStatus(m.stack || (await resolveAndPublish()).stack) }),
	SFMC_CONNECT_APP: async (m) => {
		await connectApp(m.stack, m.appId, { onLoggedOut: forgetStack });
		return { ok: true };
	},
	SFMC_WARM_UP: async (m) => {
		const { _autoStartSessions } = await storageGet("local", ["_autoStartSessions"]);
		if (_autoStartSessions === false && !m.force) return { result: { skipped: "turned off" } };
		return { result: await warmUpMissing(m.stack || (await resolveAndPublish()).stack, {
			force: !!m.force,
			onLoggedOut: forgetStack
		}) };
	},
	SFMC_FETCH: async (m) => ({ data: await sfmcFetch(m) }),
	SAVE_RECORDS: async (m) => {
		await saveRecords(m.records || {});
		return { status: "OK" };
	},
	IMPORT_SHARED_QUERY: async (m) => {
		await saveRecords(m.records || {});
		return { status: "OK" };
	},
	RENAME_QUERY: async (m) => {
		await renameQuery(m.id, m.name);
		return { status: "OK" };
	},
	TRACK_EVENT: (m) => {
		sendAnalyticsEvent(m);
		return null;
	},
	SFMC_CONTEXT_CAPTURED: (m) => {
		captureContext(m.context);
		if (m.context?.stackKey) checkWatches(m.context.stackKey).catch(() => void 0);
		return null;
	},
	WATCH_CHECK: async (m) => ({ result: await checkWatches(m.stack || (await resolveAndPublish()).stack, { force: !!m.force }) }),
	WATCH_BADGE: async () => {
		await updateBadge();
		return { ok: true };
	},
	OPEN_APP: (m, sender) => {
		const path = typeof m.path === "string" && m.path.startsWith("/") ? m.path : "/";
		createTab(nextTo(sender?.tab, { url: chrome.runtime.getURL(`${APP_PAGE}#${path}`) }));
		return { ok: true };
	},
	DASHBOARD_SUMMARY: async (m) => ({ summary: await getDashboardSummary(m.stack, { force: !!m.force }) }),
	OPEN_SFMC_LINK: async (m, sender) => {
		let ok = false;
		try {
			const u = new URL(m.url);
			ok = u.protocol === "https:" && /^mc\.s\d+\.exacttarget\.com$/i.test(u.hostname);
		} catch {}
		if (!ok) return { error: "Not an SFMC link." };
		return openSfmcLink(m.url, sender?.tab);
	},
	MCA_TOKEN_CAPTURED: (m, sender) => {
		handleCapturedToken(sender, m.accessToken);
		return null;
	}
};
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	const handler = handlers[message?.type];
	if (!handler) return false;
	Promise.resolve().then(() => handler(message, sender)).then((reply) => sendResponse(reply ?? {}), (err) => sendResponse(errorReply(err)));
	return true;
});
//#endregion
export { connectionStatus };
