//#region src/background/apps.js
var STACK_RE = /^s?\d+$/;
var SFMC_APPS = [
	{
		id: "automationStudio",
		name: "Automation Studio",
		matches: (url) => url.hostname.startsWith("mc.") && url.pathname.startsWith("/AutomationStudioFuel3/"),
		bearer: true,
		probeUrl: (s) => `https://mc.${s}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi/automation/v1/automations?$page=1&$pageSize=1`,
		landings: (s) => [`https://mc.${s}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`, `https://mc.${s}.exacttarget.com/cloud/#app/Automation%20Studio/AutomationStudioFuel3/`]
	},
	{
		id: "contactsMeta",
		name: "Data Extensions",
		matches: (url) => url.hostname.startsWith("mc.") && url.pathname.startsWith("/contactsmeta/"),
		bearer: true,
		probeUrl: (s) => `https://mc.${s}.marketingcloudapps.com/contactsmeta/fuelapi/legacy/v1/beta/folder`,
		landings: (s) => [`https://mc.${s}.marketingcloudapps.com/contactsmeta/`, `https://mc.${s}.exacttarget.com/cloud/#app/Contact%20Builder`]
	},
	{
		id: "contentBuilder",
		name: "Content Builder",
		matches: (url) => url.hostname.startsWith("content-builder."),
		bearer: true,
		csrfCookie: "_csrf",
		probeUrl: (s) => `https://content-builder.${s}.marketingcloudapps.com/fuelapi/asset/v1/content/categories/?categoryType=cloudpages&$page=1&$pagesize=1`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Content%20Builder`]
	},
	{
		id: "cloudPages",
		name: "CloudPages",
		matches: (url) => url.hostname.startsWith("cloud-pages."),
		bearer: false,
		probeUrl: (s) => `https://cloud-pages.${s}.marketingcloudapps.com/fuelapi/internal/v2/cloudpages/sites?$page=1&$pagesize=1`,
		landings: (s) => [`https://cloud-pages.${s}.marketingcloudapps.com/update-token.json`, `https://mc.${s}.exacttarget.com/cloud/#app/CloudPages`]
	},
	{
		id: "journeyBuilder",
		name: "Journey Builder",
		matches: (url) => url.hostname.startsWith("jbinteractions."),
		bearer: false,
		probeUrl: (s) => `https://jbinteractions.${s}.marketingcloudapps.com/fuelapi/interaction/v1/eventDefinitions?$page=1&$pagesize=1`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Journey%20Builder`]
	}
];
function findApp(appId) {
	return SFMC_APPS.find((a) => a.id === appId) || null;
}
function resolveUrl(rawUrl) {
	let url;
	try {
		url = new URL(rawUrl);
	} catch {
		return {
			stack: null,
			family: null,
			app: null
		};
	}
	const labels = url.hostname.split(".");
	const stack = labels.length >= 4 && STACK_RE.test(labels[1]) ? labels[1] : null;
	if (/^(?:mc|members)\.[^.]+\.exacttarget\.com$/.test(url.hostname)) return {
		stack,
		family: "core",
		app: null
	};
	if (url.hostname.endsWith(".marketingcloudapps.com")) return {
		stack,
		family: "mca",
		app: SFMC_APPS.find((a) => a.matches(url)) || null
	};
	return {
		stack: null,
		family: null,
		app: null
	};
}
function stackFromPageUrl(rawUrl) {
	if (!rawUrl || rawUrl.includes("/login") || rawUrl.includes("mc.login.")) return null;
	const m = rawUrl.match(/^https:\/\/[a-z-]+\.([^.]+)\.(?:exacttarget|marketingcloudapps)\.com\//);
	return m && STACK_RE.test(m[1]) ? m[1] : null;
}
//#endregion
//#region src/background/chromeAsync.js
function storageGet(area, keys) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].get(keys, (r) => resolve(r || {}));
		} catch {
			resolve({});
		}
	});
}
function storageSet(area, items) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].set(items, () => resolve());
		} catch {
			resolve();
		}
	});
}
function storageRemove(area, keys) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].remove(keys, () => resolve());
		} catch {
			resolve();
		}
	});
}
function queryTabs(queryInfo = {}) {
	return new Promise((resolve) => {
		try {
			chrome.tabs.query(queryInfo, (tabs) => resolve(tabs || []));
		} catch {
			resolve([]);
		}
	});
}
function getCookie(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.get(details, (c) => resolve(c || null));
		} catch {
			resolve(null);
		}
	});
}
function getAllCookies(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.getAll(details, (c) => resolve(c || []));
		} catch {
			resolve([]);
		}
	});
}
function createTab(props) {
	return new Promise((resolve) => {
		try {
			chrome.tabs.create(props, (tab) => resolve(chrome.runtime.lastError ? null : tab || null));
		} catch {
			resolve(null);
		}
	});
}
function removeTab(tabId) {
	try {
		chrome.tabs.remove(tabId, () => void chrome.runtime.lastError);
	} catch {}
}
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
//#endregion
//#region src/background/stack.js
var STACK_IDS = [
	"s1",
	"s4",
	"s6",
	"s7",
	"s8",
	"s10",
	"s11",
	"s12",
	"s13",
	"s50",
	"s51",
	"401",
	"402",
	"403"
];
var CORE_AUTH_COOKIE_NAMES = /* @__PURE__ */ new Set([
	"ETAuthCookie",
	"ASP.NET_SessionId",
	"platformAuthCookie"
]);
var STACK_FROM_CORE_HOST = /^(?:mc|members)\.([^.]+)\.exacttarget\.com$/;
var sfmcSession = {};
var forgetHooks = [];
function onForgetStack(fn) {
	forgetHooks.push(fn);
}
function rememberActiveStack(url) {
	const stack = stackFromPageUrl(url);
	if (stack) storageSet("session", { lastActiveStack: {
		stack,
		ts: Date.now()
	} });
}
async function scanCookieStacks() {
	const now = Date.now() / 1e3;
	const stacks = [];
	for (const c of await getAllCookies({ domain: "exacttarget.com" })) {
		if (!CORE_AUTH_COOKIE_NAMES.has(c.name)) continue;
		if (c.expirationDate && c.expirationDate <= now) continue;
		const m = c.domain.replace(/^\./, "").match(STACK_FROM_CORE_HOST);
		if (m && STACK_RE.test(m[1]) && !stacks.includes(m[1])) stacks.push(m[1]);
	}
	return stacks;
}
async function openStackTabs() {
	const list = [];
	for (const t of await queryTabs({})) {
		const stack = stackFromPageUrl(t.url);
		if (stack) list.push({
			stack,
			lastAccessed: t.lastAccessed || 0
		});
	}
	return list.sort((a, b) => b.lastAccessed - a.lastAccessed);
}
async function verifyStack(stack) {
	try {
		return (await fetch(`https://mc.${stack}.exacttarget.com/cloud/fuelapi/data-internal/v1/customobjects/category/0?retrievalType=1&$page=1&$pagesize=1`, {
			credentials: "include",
			redirect: "manual"
		})).status === 200;
	} catch {
		return false;
	}
}
function probeStacks() {
	return Promise.any(STACK_IDS.map((id) => fetch(`https://mc.${id}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`, {
		credentials: "include",
		redirect: "manual"
	}).then((r) => {
		if (r.status === 200) return id;
		throw new Error("not this stack");
	}))).catch(() => null);
}
async function collectStackCandidates() {
	const found = /* @__PURE__ */ new Map();
	const add = (stack, source) => {
		if (!stack || !STACK_RE.test(stack)) return;
		if (!found.has(stack)) found.set(stack, /* @__PURE__ */ new Set());
		found.get(stack).add(source);
	};
	for (const t of await openStackTabs()) add(t.stack, "tab");
	for (const s of await scanCookieStacks()) add(s, "cookie");
	for (const ctx of Object.values(sfmcSession)) add(ctx?.stackKey, "session");
	return [...found].map(([stack, sources]) => ({
		stack,
		sources: [...sources]
	}));
}
async function resolveStack() {
	const { stackOverride } = await storageGet("local", "stackOverride");
	if (stackOverride && STACK_RE.test(stackOverride)) return {
		stack: stackOverride,
		source: "manual"
	};
	const tabs = await openStackTabs();
	const { lastActiveStack } = await storageGet("session", "lastActiveStack");
	if (lastActiveStack?.stack && tabs.some((t) => t.stack === lastActiveStack.stack)) return {
		stack: lastActiveStack.stack,
		source: "tab"
	};
	if (tabs.length) return {
		stack: tabs[0].stack,
		source: "tab"
	};
	const cookieStacks = await scanCookieStacks();
	if (cookieStacks.length === 1) return {
		stack: cookieStacks[0],
		source: "cookie"
	};
	if (cookieStacks.length > 1) {
		const checks = await Promise.all(cookieStacks.map(verifyStack));
		const live = cookieStacks.find((_, i) => checks[i]);
		return live ? {
			stack: live,
			source: "cookie"
		} : {
			stack: null,
			source: null
		};
	}
	const probed = await probeStacks();
	return {
		stack: probed,
		source: probed ? "probe" : null
	};
}
async function publishStack(stack) {
	if (!stack) return;
	const { sfmcStack } = await storageGet("local", "sfmcStack");
	if (sfmcStack !== stack) await storageSet("local", {
		sfmcStack: stack,
		sfmcStackTs: Date.now()
	});
}
async function resolveAndPublish() {
	const resolved = await resolveStack();
	if (resolved.stack) await publishStack(resolved.stack);
	return resolved;
}
async function forgetStack(stack) {
	if (!stack) return;
	console.warn("[Toolkit:SW] Forgetting stack after an auth failure:", stack);
	for (const fn of forgetHooks) fn(stack);
	for (const [k, ctx] of Object.entries(sfmcSession)) if (ctx?.stackKey === stack) delete sfmcSession[k];
	const { sfmcStack } = await storageGet("local", "sfmcStack");
	if (sfmcStack === stack) await storageRemove("local", ["sfmcStack", "sfmcStackTs"]);
	const { lastActiveStack } = await storageGet("session", "lastActiveStack");
	if (lastActiveStack?.stack === stack) await storageRemove("session", "lastActiveStack");
}
async function getStacks() {
	const [candidates, resolved, { stackOverride }] = await Promise.all([
		collectStackCandidates(),
		resolveStack(),
		storageGet("local", "stackOverride")
	]);
	return {
		candidates,
		resolved: resolved.stack,
		source: resolved.source,
		override: stackOverride || null
	};
}
async function setStackOverride(value) {
	const stack = value ? String(value).trim().toLowerCase() : null;
	if (stack && !STACK_RE.test(stack)) return { error: "A stack looks like s10 or 401." };
	if (stack) await storageSet("local", { stackOverride: stack });
	else await storageRemove("local", "stackOverride");
	const r = await resolveAndPublish();
	return {
		stack: r.stack,
		source: r.source
	};
}
function captureContext(ctx) {
	if (!ctx?.hostname) return;
	sfmcSession[ctx.hostname] = ctx;
	if (ctx.stackKey) sfmcSession["_stack_" + ctx.stackKey] = ctx;
}
async function getSession(stackKey) {
	if (stackKey && sfmcSession["_stack_" + stackKey]) return { session: sfmcSession["_stack_" + stackKey] };
	const { stack } = await resolveAndPublish();
	if (!stack) return { session: null };
	return { session: sfmcSession["_stack_" + stack] || { stackKey: stack } };
}
//#endregion
//#region src/background/csrf.js
var MAX_AGE = 84e4;
var csrfCache = {};
async function restoreCsrfTokens() {
	const { _csrfTokens: stored = {} } = await storageGet("local", "_csrfTokens");
	const now = Date.now();
	for (const [stack, entry] of Object.entries(stored)) if (entry?.csrfToken && now - (entry.csrfCapturedAt || 0) < MAX_AGE) csrfCache[stack] = {
		token: entry.csrfToken,
		capturedAt: entry.csrfCapturedAt
	};
}
async function rememberCsrf(stack, token) {
	if (!stack || !token || token === csrfCache[stack]?.token) return;
	const capturedAt = Date.now();
	csrfCache[stack] = {
		token,
		capturedAt
	};
	const { _csrfTokens: stored = {} } = await storageGet("local", "_csrfTokens");
	stored[stack] = {
		csrfToken: token,
		csrfCapturedAt: capturedAt
	};
	await storageSet("local", { _csrfTokens: stored });
}
function getCoreCsrf(stack) {
	const entry = stack && csrfCache[stack];
	return entry && Date.now() - entry.capturedAt < MAX_AGE ? entry.token : null;
}
function sniffCsrf(details) {
	if (!details.requestHeaders) return;
	const m = details.url.match(/(?:mc|members)\.([^.]+)\.exacttarget\.com/);
	if (!m) return;
	const h = details.requestHeaders.find((x) => x.name.toLowerCase() === "x-csrf-token");
	if (h?.value) rememberCsrf(m[1], h.value);
}
async function getAppCsrf(rawUrl, cookieName = "_csrf") {
	try {
		const cookie = await getCookie({
			url: new URL(rawUrl).origin + "/",
			name: cookieName
		});
		if (!cookie?.value) return null;
		try {
			return decodeURIComponent(cookie.value);
		} catch {
			return cookie.value;
		}
	} catch {
		return null;
	}
}
//#endregion
//#region src/background/mcaToken.js
var mintTiming = {
	timeoutMs: 1e4,
	backoffMs: 12e4
};
var tokenCache = {};
var inFlight$1 = {};
var failedAt$1 = {};
var pendingByTab = /* @__PURE__ */ new Map();
var onMintFailure = () => {};
function setOnMintFailure(fn) {
	onMintFailure = fn;
}
function mintBackoff(stack) {
	return Date.now() - (failedAt$1[stack] || 0) < mintTiming.backoffMs;
}
function isMcaTokenReady(stack) {
	const cached = stack && tokenCache[stack];
	return !!cached && Date.now() < cached.expiresAt;
}
function dropMcaToken(stack) {
	delete tokenCache[stack];
}
function decodeJwtExp(jwt) {
	try {
		const payload = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
		const json = JSON.parse(atob(payload + "===".slice((payload.length + 3) % 4)));
		return json.exp ? json.exp * 1e3 : null;
	} catch {
		return null;
	}
}
function handleCapturedToken(sender, accessToken) {
	const resolve = pendingByTab.get(sender?.tab?.id);
	if (resolve) resolve(accessToken || null);
}
function mint(stack) {
	if (inFlight$1[stack]) return inFlight$1[stack];
	const promise = new Promise((resolve) => {
		let settled = false;
		let tabId = null;
		const finish = (token) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			if (tabId != null) {
				pendingByTab.delete(tabId);
				removeTab(tabId);
			}
			resolve(token);
		};
		const timer = setTimeout(() => {
			console.warn("[Toolkit:SW] MCA token mint timed out for stack:", stack);
			finish(null);
		}, mintTiming.timeoutMs);
		createTab({
			url: `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`,
			active: false
		}).then((tab) => {
			if (!tab) return finish(null);
			tabId = tab.id;
			if (settled) return removeTab(tabId);
			pendingByTab.set(tabId, finish);
		});
	}).finally(() => {
		delete inFlight$1[stack];
	});
	inFlight$1[stack] = promise;
	return promise;
}
async function getMcaToken(stack) {
	if (!stack) return null;
	if (isMcaTokenReady(stack)) return tokenCache[stack].accessToken;
	if (mintBackoff(stack)) return null;
	const accessToken = await mint(stack);
	if (!accessToken) {
		failedAt$1[stack] = Date.now();
		onMintFailure(stack);
		return null;
	}
	delete failedAt$1[stack];
	tokenCache[stack] = {
		accessToken,
		expiresAt: (decodeJwtExp(accessToken) || Date.now() + 6e5) - 3e4
	};
	return accessToken;
}
//#endregion
//#region src/background/sessions.js
var LOGIN_REQUIRED = "SFMC_LOGIN_REQUIRED";
var SESSION_UNAVAILABLE = "SFMC_SESSION_UNAVAILABLE";
var timing = {
	pollMs: 1e3,
	landingTimeoutMs: 15e3,
	cooldownMs: 3e4
};
var LOGIN_COOKIES = [{
	host: (s) => `mc.${s}.exacttarget.com`,
	name: "platformAuthCookie"
}, {
	host: (s) => `members.${s}.exacttarget.com`,
	name: "ETAuthCookie"
}];
var inFlight = /* @__PURE__ */ new Map();
var failedAt = /* @__PURE__ */ new Map();
var starting = /* @__PURE__ */ new Set();
var warmedAt = /* @__PURE__ */ new Map();
var SfmcAuthError = class extends Error {
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
async function isLoggedIn(stack) {
	for (const c of LOGIN_COOKIES) if (await getCookie({
		url: `https://${c.host(stack)}/`,
		name: c.name
	})) return true;
	return false;
}
async function probeSession(app, stack) {
	try {
		return (await fetch(app.probeUrl(stack), {
			credentials: "include",
			redirect: "manual"
		})).status === 200;
	} catch {
		return false;
	}
}
async function tryLanding(app, stack, landingUrl) {
	const tab = await createTab({
		url: landingUrl,
		active: false
	});
	if (!tab) return false;
	try {
		const deadline = Date.now() + timing.landingTimeoutMs;
		while (Date.now() < deadline) {
			await delay(timing.pollMs);
			if (await probeSession(app, stack)) return true;
		}
		return false;
	} finally {
		removeTab(tab.id);
	}
}
function ensureSession(app, stack, { onLoggedOut } = {}) {
	const key = `${stack}:${app.id}`;
	if (inFlight.has(key)) return inFlight.get(key);
	const last = failedAt.get(key);
	if (last && Date.now() - last < timing.cooldownMs) return Promise.reject(new SfmcAuthError(SESSION_UNAVAILABLE, `Could not start a ${app.name} session on stack ${stack}.`));
	const promise = (async () => {
		if (await probeSession(app, stack)) return;
		if (!await isLoggedIn(stack)) {
			await onLoggedOut?.(stack);
			throw new SfmcAuthError(LOGIN_REQUIRED, `Not logged in to Marketing Cloud on stack ${stack}.`);
		}
		for (const url of app.landings(stack)) if (await tryLanding(app, stack, url)) return;
		throw new SfmcAuthError(SESSION_UNAVAILABLE, `Could not start a ${app.name} session on stack ${stack}.`);
	})().then(() => {
		failedAt.delete(key);
	}).catch((err) => {
		failedAt.set(key, Date.now());
		throw err;
	}).finally(() => {
		inFlight.delete(key);
	});
	inFlight.set(key, promise);
	return promise;
}
async function sessionStatus(stack) {
	const loggedIn = await isLoggedIn(stack);
	return {
		stack,
		loggedIn,
		apps: await Promise.all(SFMC_APPS.map(async (app) => ({
			id: app.id,
			name: app.name,
			ok: loggedIn && await probeSession(app, stack),
			starting: starting.has(`${stack}:${app.id}`)
		})))
	};
}
async function connectApp(stack, appId, opts) {
	const app = findApp(appId);
	if (!app) throw new Error(`Unknown SFMC app: ${appId}`);
	failedAt.delete(`${stack}:${app.id}`);
	await ensureSession(app, stack, opts);
}
/**
* Starts the app sessions that are missing, but only when at least one app already
* has a session: then the user is logged in and SFMC answers, so the rest can be
* started. With none, the user is most likely not logged in and opening tabs would
* not help. Apps are started one at a time (one inactive tab each), at most once
* every 10 minutes per stack unless `force`.
* @returns {{ skipped?: string, started?: string[], failed?: string[] }}
*/
async function warmUpMissing(stack, { force = false, onLoggedOut } = {}) {
	if (!stack) return { skipped: "no stack" };
	const last = warmedAt.get(stack);
	if (!force && last && Date.now() - last < 6e5) return { skipped: "recently" };
	const status = await sessionStatus(stack);
	if (!status.loggedIn) return { skipped: "not logged in" };
	if (!status.apps.some((a) => a.ok)) return { skipped: "no app session" };
	warmedAt.set(stack, Date.now());
	const missing = status.apps.filter((a) => !a.ok).map((a) => findApp(a.id));
	const started = [];
	const failed = [];
	for (const app of missing) starting.add(`${stack}:${app.id}`);
	try {
		for (const app of missing) try {
			failedAt.delete(`${stack}:${app.id}`);
			await ensureSession(app, stack, { onLoggedOut });
			started.push(app.id);
		} catch (e) {
			failed.push(app.id);
			if (e.code === "SFMC_LOGIN_REQUIRED") break;
		} finally {
			starting.delete(`${stack}:${app.id}`);
		}
	} finally {
		for (const app of missing) starting.delete(`${stack}:${app.id}`);
	}
	return {
		started,
		failed
	};
}
//#endregion
//#region src/background/fetchProxy.js
var SfmcApiError = class extends Error {
	constructor(status, text) {
		super(`SFMC API error ${status}: ${String(text).substring(0, 300)}`);
		this.status = status;
	}
};
var needsSession = (res) => res.status === 401 || res.type === "opaqueredirect";
async function send(url, method, body, headers) {
	const opts = {
		method,
		credentials: "include",
		redirect: "manual",
		headers: {
			"Content-Type": "application/json",
			...headers
		}
	};
	if (body != null) opts.body = typeof body === "string" ? body : JSON.stringify(body);
	try {
		return await fetch(url, opts);
	} catch (err) {
		return {
			ok: false,
			status: 0,
			type: "error",
			headers: new Headers(),
			text: async () => err.message
		};
	}
}
async function authHeaders({ url, stack, family, app, mutating }) {
	const headers = {};
	if (family === "core") {
		const csrf = mutating && getCoreCsrf(stack);
		if (csrf) headers["X-CSRF-Token"] = csrf;
	} else if (family === "mca") {
		if (app?.bearer) {
			const token = await getMcaToken(stack);
			if (token) headers.Authorization = `Bearer ${token}`;
		}
		if (mutating) {
			const csrf = await getAppCsrf(url, app?.csrfCookie || "_csrf");
			if (csrf) headers["X-CSRF-Token"] = csrf;
		}
	}
	return headers;
}
async function sfmcFetch({ url, method = "GET", body = null, bootstrap = true }) {
	const target = {
		url,
		...resolveUrl(url),
		mutating: method !== "GET" && method !== "HEAD"
	};
	const { stack, family, app } = target;
	let headers = await authHeaders(target);
	let res = await send(url, method, body, headers);
	if (res.status === 403 && family === "mca" && headers["X-CSRF-Token"]) {
		headers = await authHeaders(target);
		res = await send(url, method, body, headers);
	}
	if (needsSession(res) && app?.bearer && headers.Authorization) {
		dropMcaToken(stack);
		headers = await authHeaders(target);
		if (headers.Authorization) res = await send(url, method, body, headers);
	}
	if (needsSession(res) && app && stack && bootstrap) {
		await ensureSession(app, stack, { onLoggedOut: forgetStack });
		headers = await authHeaders(target);
		res = await send(url, method, body, headers);
	}
	if (needsSession(res)) {
		await forgetStack(stack);
		throw new SfmcAuthError(LOGIN_REQUIRED, "SFMC session expired (401). Please log in to SFMC in any tab, then try again.");
	}
	const text = await res.text();
	if (family === "core" && stack) {
		const fresh = res.headers?.get?.("x-csrf-token");
		if (fresh) rememberCsrf(stack, fresh);
	}
	if (!res.ok) throw new SfmcApiError(res.status, text);
	if (!text) return null;
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
}
//#endregion
//#region src/background/businessUnit.js
var cache = {};
var TTL = 6e4;
function toBusinessUnit(d) {
	if (!d?.name) return null;
	return {
		name: d.name,
		accountId: d.accountId ?? d.id ?? d.memberId ?? null
	};
}
async function fetchCurrentBusinessUnit(stack) {
	const hit = cache[stack];
	if (hit && Date.now() - hit.ts < TTL) return hit.bu;
	const res = await fetch(`https://mc.${stack}.exacttarget.com/cloud/fuelapi/platform-internal/v1/accounts/@current`, {
		credentials: "include",
		redirect: "manual"
	});
	if (res.status !== 200) return null;
	const bu = toBusinessUnit(await res.json());
	cache[stack] = {
		ts: Date.now(),
		bu
	};
	return bu;
}
//#endregion
//#region src/background/capture.js
var decoder = new TextDecoder("utf-8");
async function blinkIcon() {
	try {
		chrome.action.setIcon({ path: "/images/icon48x48-off.png" });
		await delay(5e3);
		chrome.action.setIcon({ path: "/images/icon48x48.png" });
	} catch {}
}
async function saveRecords(records) {
	blinkIcon();
	await storageSet("local", records);
}
async function renameQuery(id, name) {
	const rec = (await storageGet("local", id))[id];
	if (rec) await storageSet("local", { [id]: {
		...rec,
		name
	} });
}
async function tagBusinessUnit(id) {
	try {
		const { stack } = await resolveStack();
		if (!stack) return;
		const bu = await fetchCurrentBusinessUnit(stack);
		if (!bu) return;
		const rec = (await storageGet("local", id))[id];
		if (!rec || rec.businessUnit?.name) return;
		await storageSet("local", { [id]: {
			...rec,
			businessUnit: {
				...rec.businessUnit || {},
				...bu
			}
		} });
	} catch (e) {
		console.warn("[Toolkit:SW] Could not tag the business unit:", e?.message);
	}
}
async function captureQueryStudio(details) {
	if (details.method !== "POST" || !details.requestBody?.raw?.[0]?.bytes) return;
	let queryText;
	try {
		queryText = JSON.parse(decoder.decode(new Uint8Array(details.requestBody.raw[0].bytes))).querytext;
	} catch {
		return;
	}
	if (!queryText) return;
	const ts = details.timeStamp;
	const id = "sql_" + ts;
	await saveRecords({ [id]: {
		id,
		queryText,
		timeStamp: ts,
		url: details.url,
		name: new Date(ts).toDateString() + " " + new Date(ts).toLocaleTimeString(),
		isFavourite: false
	} });
	await tagBusinessUnit(id);
}
var emailSaver = {
	enabled: true,
	debounceMs: 5e3
};
var lastSavedAt = {};
async function loadEmailSaverPrefs() {
	applyEmailSaverPrefs(await storageGet("local", ["_emailSaverEnabled", "_emailSaveDebounce"]));
}
function applyEmailSaverPrefs(prefs) {
	if ("_emailSaverEnabled" in prefs) emailSaver.enabled = prefs._emailSaverEnabled !== false;
	if ("_emailSaveDebounce" in prefs) {
		const s = prefs._emailSaveDebounce;
		emailSaver.debounceMs = typeof s === "number" && s >= 0 ? s * 1e3 : 5e3;
	}
}
function pickView(view) {
	if (!view) return null;
	return {
		content: view.content || null,
		superContent: view.superContent || null,
		design: view.design || null,
		slots: view.slots || null,
		blocks: view.blocks || null
	};
}
async function captureEmail(details) {
	if (!emailSaver.enabled || details.method !== "PUT") return;
	if (!details.requestBody?.raw?.[0]?.bytes) return;
	let jsonStr, asset;
	try {
		jsonStr = decoder.decode(new Uint8Array(details.requestBody.raw[0].bytes));
		asset = JSON.parse(jsonStr);
	} catch {
		return;
	}
	if (!(asset.assetType?.name || "").toLowerCase().includes("email")) return;
	const assetId = asset.id || Number(details.url.split("/").pop());
	const now = Date.now();
	if (emailSaver.debounceMs > 0 && now - (lastSavedAt[assetId] || 0) < emailSaver.debounceMs) return;
	lastSavedAt[assetId] = now;
	const key = `email_${assetId}`;
	const stack = details.url.match(/content-builder\.([^.]+)\.marketingcloudapps\.com/)?.[1] || null;
	const compileAsset = {
		superContent: asset.superContent || null,
		content: asset.content || null,
		design: asset.design || null,
		slots: asset.slots || null,
		blocks: asset.blocks || null,
		views: { html: pickView(asset.views?.html) }
	};
	const assetBody = JSON.parse(jsonStr);
	if (assetBody.views) assetBody.views = {
		...asset.views.subjectline ? { subjectline: asset.views.subjectline } : {},
		...asset.views.preheader ? { preheader: asset.views.preheader } : {},
		...asset.views.html ? { html: asset.views.html } : {}
	};
	delete assetBody.thumbnail;
	const subject = asset.views?.subjectline?.content || "";
	const version = {
		versionId: `v_${now}`,
		savedAt: now,
		subject,
		name: asset.name || `Email ${assetId}`,
		status: asset.status?.name || "Draft",
		categoryName: asset.category?.name || "",
		compileAsset,
		assetBody,
		stack
	};
	const prev = (await storageGet("local", key))[key];
	await saveRecords({ [key]: {
		id: key,
		assetId: Number(assetId),
		customerKey: asset.customerKey || "",
		name: asset.name || `Email ${assetId}`,
		assetTypeName: asset.assetType?.name || "",
		assetTypeDisplayName: asset.assetType?.displayName || "",
		status: asset.status?.name || "Draft",
		categoryId: asset.category?.id || null,
		categoryName: asset.category?.name || "",
		subject,
		compileAsset,
		ownerName: asset.owner?.name || "",
		ownerEmail: asset.owner?.email || "",
		memberId: asset.memberId || null,
		enterpriseId: asset.enterpriseId || null,
		createdDate: asset.createdDate || null,
		modifiedDate: asset.modifiedDate || null,
		isFavourite: prev?.isFavourite || false,
		timeStamp: prev?.timeStamp || now,
		versions: [version, ...Array.isArray(prev?.versions) ? prev.versions : []]
	} });
}
//#endregion
//#region src/background/analytics.js
var GA4_MEASUREMENT_ID = "G-KYHPC12MT9";
var GA4_API_SECRET = "AacKkgqYTri0uyyZm3Dqhw";
async function sendAnalyticsEvent({ clientId, name, params }) {
	if (!clientId || !name) return;
	try {
		await fetch(`https://www.google-analytics.com/mp/collect?measurement_id=${GA4_MEASUREMENT_ID}&api_secret=${GA4_API_SECRET}`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				client_id: clientId,
				events: [{
					name,
					params: {
						...params,
						app: "toolkit",
						extension_version: chrome.runtime.getManifest().version
					}
				}]
			})
		});
	} catch (e) {
		console.warn("[Toolkit:SW] Analytics send failed:", e.message);
	}
}
var QUERY_STUDIO_CREATE_URLS = ["https://querystudio.herokuapp.com/query/create", ...["https://querystudio2-dev-89f7e4653c61.herokuapp.com/*"].map((o) => o.replace(/\*$/, "query/create"))];
//#endregion
//#region src/background/updates.js
var UPDATE_KEY = "_updateAvailable";
function note(version) {
	if (version) chrome.storage.local.set({ [UPDATE_KEY]: {
		version,
		at: Date.now()
	} });
}
function watchForUpdates() {
	chrome.runtime.onUpdateAvailable?.addListener((details) => note(details?.version));
	chrome.runtime.onInstalled?.addListener(() => chrome.storage.local.remove(UPDATE_KEY));
	try {
		chrome.runtime.requestUpdateCheck?.((status, details) => {
			chrome.runtime.lastError;
			if (status === "update_available") note(details?.version);
		});
	} catch {}
}
//#endregion
//#region src/utils/watches.js
var WATCHES_KEY = "toolkit_watches";
var NOTICES_KEY = "toolkit_watch_notices";
var NOTIFY_KEY = "toolkit_watch_desktop";
var DEFAULT_ON = {
	paused: true,
	activated: true,
	runs: false,
	fails: true
};
var STATUS_NAMES = {
	"-1": "Error",
	0: "Build error",
	1: "Building",
	2: "Ready",
	3: "Running",
	4: "Paused",
	5: "Stopped",
	6: "Scheduled",
	7: "Awaiting trigger",
	8: "Inactive trigger"
};
function automationStatusName(v) {
	if (v == null || v === "") return "";
	const n = Number(v);
	if (Number.isInteger(n) && String(n) === String(v).trim() && STATUS_NAMES[n] != null) return STATUS_NAMES[n];
	return String(v);
}
var isPausedLike = (s) => /^(paused|stopped)$/i.test(s);
var isActiveLike = (s) => /^(scheduled|awaiting trigger|running)$/i.test(s);
var isFailure = (s) => /error|fail/i.test(String(s || ""));
var time = (v) => {
	const t = Date.parse(v || "");
	return Number.isNaN(t) ? 0 : t;
};
/**
* Notices for the change from `prev` to `cur` ({ status, lastRunTime, lastRunStatus }),
* for the kinds switched on in `on`. No notices without a previous snapshot.
*/
function diffAutomation(prev, cur, on = DEFAULT_ON) {
	if (!prev || !cur) return [];
	const out = [];
	const was = automationStatusName(prev.status);
	const now = automationStatusName(cur.status);
	if (now && was && now !== was) {
		if (isPausedLike(now) && on.paused) out.push({
			kind: "paused",
			text: `is now ${now} (was ${was})`
		});
		else if (isActiveLike(now) && !isActiveLike(was) && on.activated) out.push({
			kind: "activated",
			text: `is now ${now} (was ${was})`
		});
	}
	if (time(cur.lastRunTime) > time(prev.lastRunTime)) {
		if (isFailure(cur.lastRunStatus) && on.fails) out.push({
			kind: "fails",
			text: `run failed${cur.lastRunStatus ? ` (${cur.lastRunStatus})` : ""}`
		});
		else if (on.runs) out.push({
			kind: "runs",
			text: `ran${cur.lastRunStatus ? `: ${cur.lastRunStatus}` : ""}`
		});
	}
	return out;
}
/** Adds notices (newest first), keeping at most MAX_NOTICES. */
function addNotices(list, watch, changes, now = Date.now()) {
	return [...changes.map((c, i) => ({
		id: `${now.toString(36)}${i}${Math.random().toString(36).slice(2, 6)}`,
		at: now,
		stack: watch.stack,
		automationId: watch.id,
		name: watch.name,
		kind: c.kind,
		text: c.text,
		read: false
	})), ...Array.isArray(list) ? list : []].slice(0, 50);
}
var unreadCount = (list) => Array.isArray(list) ? list.filter((n) => !n.read).length : 0;
//#endregion
//#region src/background/watches.js
var AS = (stack) => `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi`;
var CHECKED_KEY = "toolkit_watch_checked";
var PAGE_INTERVAL = 9e5;
var running = /* @__PURE__ */ new Set();
async function snapshot(stack, w) {
	const d = await sfmcFetch({ url: `${AS(stack)}/automation/v1/automations/${encodeURIComponent(w.id)}` });
	const snap = {
		status: d?.status ?? null,
		lastRunTime: d?.lastRunTime ?? null,
		lastRunStatus: d?.lastRunStatus ?? null,
		name: d?.name || w.name
	};
	if (snap.lastRunTime && snap.lastRunTime !== w.last?.lastRunTime && !snap.lastRunStatus) try {
		const day = (t) => new Date(t).toISOString().slice(0, 10);
		const runs = await sfmcFetch({ url: `${AS(stack)}/legacy/v1/beta/automations/automation/instance/?definition_id=${encodeURIComponent(w.id)}&$top=1&begin_date=${day(Date.now() - 6048e5)}&end_date=${day(Date.now())}&order_by=${encodeURIComponent("StartTime desc")}&to_server_time=1` });
		const r = (runs?.entry || runs?.items || [])[0];
		snap.lastRunStatus = r?.status ?? r?.statusName ?? r?.StatusName ?? null;
	} catch {}
	return snap;
}
async function updateBadge(list) {
	const n = unreadCount(list ?? (await storageGet("local", ["toolkit_watch_notices"]))["toolkit_watch_notices"]);
	try {
		await chrome.action?.setBadgeText?.({ text: n ? String(Math.min(n, 99)) : "" });
		if (n) await chrome.action?.setBadgeBackgroundColor?.({ color: "#d03b3b" });
	} catch {}
}
/** Checks the stack's watched automations; `force` skips the 15-minute wait. Returns { checked, notices }. */
async function checkWatches(stack, { force = false } = {}) {
	if (!stack || running.has(stack)) return {
		checked: 0,
		notices: 0
	};
	const store = await storageGet("local", [
		WATCHES_KEY,
		NOTICES_KEY,
		CHECKED_KEY,
		NOTIFY_KEY
	]);
	const watches = store["toolkit_watches"] || {};
	const mine = Object.entries(watches).filter(([, w]) => w.stack === stack);
	const checkedAt = store[CHECKED_KEY] || {};
	if (!mine.length || !force && Date.now() - (checkedAt[stack] || 0) < PAGE_INTERVAL) return {
		checked: 0,
		notices: 0
	};
	running.add(stack);
	try {
		let notices = store["toolkit_watch_notices"] || [];
		const fresh = [];
		for (const [k, w] of mine) try {
			const cur = await snapshot(stack, w);
			const changes = diffAutomation(w.last, cur, w.on);
			if (changes.length) {
				notices = addNotices(notices, {
					...w,
					name: cur.name
				}, changes);
				fresh.push(...changes.map((c) => `${cur.name} ${c.text}`));
			}
			watches[k] = {
				...w,
				name: cur.name,
				last: {
					status: cur.status,
					statusName: automationStatusName(cur.status),
					lastRunTime: cur.lastRunTime,
					lastRunStatus: cur.lastRunStatus
				},
				checkedAt: Date.now()
			};
		} catch (e) {
			watches[k] = {
				...w,
				error: e?.message || String(e),
				checkedAt: Date.now()
			};
		}
		await chrome.storage.local.set({
			[WATCHES_KEY]: watches,
			[NOTICES_KEY]: notices,
			[CHECKED_KEY]: {
				...checkedAt,
				[stack]: Date.now()
			}
		});
		await updateBadge(notices);
		if (fresh.length && store["toolkit_watch_desktop"] && chrome.notifications?.create) chrome.notifications.create({
			type: "basic",
			iconUrl: chrome.runtime.getURL("images/icon128x128.png"),
			title: "SFMC Toolkit: watched automations",
			message: fresh.slice(0, 3).join("\n") + (fresh.length > 3 ? `\n+${fresh.length - 3} more` : "")
		});
		return {
			checked: mine.length,
			notices: fresh.length
		};
	} finally {
		running.delete(stack);
	}
}
//#endregion
//#region src/background/index.js
onForgetStack(dropMcaToken);
setOnMintFailure(forgetStack);
restoreCsrfTokens();
loadEmailSaverPrefs();
watchForUpdates();
updateBadge();
var APP_PAGE = "app.html";
chrome.action?.onClicked?.addListener(() => {
	createTab({ url: chrome.runtime.getURL(APP_PAGE) });
});
chrome.tabs?.onActivated?.addListener(({ tabId }) => {
	chrome.tabs.get(tabId, (tab) => {
		if (!chrome.runtime.lastError && tab) rememberActiveStack(tab.url);
	});
});
chrome.tabs?.onUpdated?.addListener((tabId, info, tab) => {
	if (info.status === "complete" && tab?.active) rememberActiveStack(tab.url);
});
chrome.storage?.onChanged?.addListener((changes, area) => {
	if (area !== "local") return;
	const prefs = {};
	for (const k of ["_emailSaverEnabled", "_emailSaveDebounce"]) if (k in changes) prefs[k] = changes[k].newValue;
	applyEmailSaverPrefs(prefs);
});
chrome.webRequest?.onBeforeSendHeaders.addListener(sniffCsrf, { urls: ["https://*.exacttarget.com/*"] }, ["requestHeaders", "extraHeaders"]);
chrome.webRequest?.onBeforeRequest.addListener(captureQueryStudio, { urls: QUERY_STUDIO_CREATE_URLS }, ["requestBody"]);
chrome.webRequest?.onBeforeRequest.addListener(captureEmail, { urls: ["https://*.marketingcloudapps.com/fuelapi/asset/v1/content/assets/*"] }, ["requestBody"]);
var isSfmcUrl = (u) => /^https:\/\/[^/]*\.(exacttarget|marketingcloudapps|marketingcloud|salesforce-marketingcloud)\.com\//.test(u || "");
var isLoggedInUrl = (u) => !u.includes("/login") && !u.includes("mc.login.") && !u.includes("sso");
async function connectionStatus() {
	const { stack } = await resolveAndPublish();
	if (stack && !isMcaTokenReady(stack) && !mintBackoff(stack)) getMcaToken(stack);
	let coreOpen = false;
	let contentBuilderOpen = false;
	for (const t of await queryTabs({})) {
		const u = t.url || "";
		if (!isSfmcUrl(u) || !isLoggedInUrl(u)) continue;
		if (u.includes("content-builder.")) contentBuilderOpen = true;
		else if (u.includes("mc.") || u.includes("members.")) coreOpen = true;
	}
	return {
		stack,
		connected: !!stack,
		tokenReady: !!getCoreCsrf(stack),
		mcaTokenReady: isMcaTokenReady(stack),
		areas: {
			core: { open: coreOpen },
			contentBuilder: { open: contentBuilderOpen }
		}
	};
}
function errorReply(err) {
	return {
		error: err?.message || String(err),
		code: err?.code || null,
		status: err?.status ?? null
	};
}
var handlers = {
	PING: () => ({ ok: true }),
	GET_SESSION: (m) => getSession(m.stackKey),
	GET_STACKS: () => getStacks(),
	SET_STACK_OVERRIDE: (m) => setStackOverride(m.stack),
	GET_CONNECTION_STATUS: () => connectionStatus(),
	SFMC_SESSION_STATUS: async (m) => ({ status: await sessionStatus(m.stack || (await resolveAndPublish()).stack) }),
	SFMC_CONNECT_APP: async (m) => {
		await connectApp(m.stack, m.appId, { onLoggedOut: forgetStack });
		return { ok: true };
	},
	SFMC_WARM_UP: async (m) => {
		const { _autoStartSessions } = await storageGet("local", ["_autoStartSessions"]);
		if (_autoStartSessions === false && !m.force) return { result: { skipped: "turned off" } };
		return { result: await warmUpMissing(m.stack || (await resolveAndPublish()).stack, {
			force: !!m.force,
			onLoggedOut: forgetStack
		}) };
	},
	SFMC_FETCH: async (m) => ({ data: await sfmcFetch(m) }),
	SAVE_RECORDS: async (m) => {
		await saveRecords(m.records || {});
		return { status: "OK" };
	},
	IMPORT_SHARED_QUERY: async (m) => {
		await saveRecords(m.records || {});
		return { status: "OK" };
	},
	RENAME_QUERY: async (m) => {
		await renameQuery(m.id, m.name);
		return { status: "OK" };
	},
	TRACK_EVENT: (m) => {
		sendAnalyticsEvent(m);
		return null;
	},
	SFMC_CONTEXT_CAPTURED: (m) => {
		captureContext(m.context);
		if (m.context?.stackKey) checkWatches(m.context.stackKey).catch(() => void 0);
		return null;
	},
	WATCH_CHECK: async (m) => ({ result: await checkWatches(m.stack || (await resolveAndPublish()).stack, { force: !!m.force }) }),
	WATCH_BADGE: async () => {
		await updateBadge();
		return { ok: true };
	},
	MCA_TOKEN_CAPTURED: (m, sender) => {
		handleCapturedToken(sender, m.accessToken);
		return null;
	}
};
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	const handler = handlers[message?.type];
	if (!handler) return false;
	Promise.resolve().then(() => handler(message, sender)).then((reply) => sendResponse(reply ?? {}), (err) => sendResponse(errorReply(err)));
	return true;
});
//#endregion
export { connectionStatus };
